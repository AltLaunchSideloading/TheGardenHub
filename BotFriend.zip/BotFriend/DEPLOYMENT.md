# Deployment Guide

This Discord bot can be deployed on various platforms without requiring Replit-specific secrets or environment variables. Here's how to deploy it on popular platforms:

## 🚀 Platform-Specific Deployment

### Replit
1. Fork/import the project
2. Run `python main.py`
3. Enter your Discord bot token when prompted
4. Bot will run automatically

### Heroku
1. Create a new Heroku app
2. Upload your code or connect to GitHub
3. Add a `Procfile` with: `worker: python main.py`
4. Deploy the app
5. Scale up the worker dyno
6. Check logs and enter token when prompted

### Railway
1. Create a new Railway project
2. Connect your GitHub repository
3. Railway will auto-detect Python and install dependencies
4. Set start command to `python main.py`
5. Deploy and check logs for token prompt

### Local Machine (Windows/Mac/Linux)
```bash
# Install Python 3.8+
# Clone/download the project
cd discord-bot
pip install discord.py python-dotenv aiosqlite
python main.py
# Enter token when prompted
```

### Google Cloud Run
1. Create a `Dockerfile`:
```dockerfile
FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
CMD ["python", "main.py"]
```

2. Create `requirements.txt`:
```
discord.py
python-dotenv
aiosqlite
```

3. Deploy to Cloud Run
4. Set up Cloud Logging to see token prompt

### DigitalOcean App Platform
1. Create new app from GitHub
2. Set build command: `pip install -r requirements.txt`
3. Set run command: `python main.py`
4. Deploy and check logs

### PythonAnywhere
1. Upload files to your account
2. Open a bash console
3. Install dependencies: `pip3.11 install --user discord.py python-dotenv aiosqlite`
4. Run: `python3.11 main.py`
5. Enter token when prompted

### AWS EC2 / VPS
```bash
# Connect to your server
sudo apt update
sudo apt install python3 python3-pip
pip3 install discord.py python-dotenv aiosqlite

# Upload your bot files
python3 main.py
# Enter token when prompted

# To run permanently:
nohup python3 main.py &
```

## 📋 Requirements File

Create `requirements.txt` for platforms that need it:
```
discord.py>=2.3.0
python-dotenv>=1.0.0
aiosqlite>=0.19.0
```

## 🔧 Environment Setup

No environment variables are required! The bot supports multiple setup options:

**Option 1: Direct code setup (Easiest)**
1. Edit `main.py` line 99: `BOT_TOKEN = "your_actual_token"`
2. Run the bot - no prompts needed!

**Option 2: Interactive setup**
1. Run the bot
2. Enter token when prompted
3. Token gets saved to `config.json` for future runs

**Auto-generated files:**
- Database file (`bot.db`) - created automatically
- Default configuration - generated on first run

## 🛠️ Troubleshooting Common Issues

### "Module not found" errors
- Ensure all dependencies are installed: `pip install discord.py python-dotenv aiosqlite`

### "Permission denied" on file creation
- Make sure the bot has write permissions to its directory
- On some platforms, use `/tmp/` for temporary files

### Bot doesn't respond to commands
- Ensure bot has proper permissions in Discord server
- Check that slash commands are synced (happens automatically on startup)
- Verify bot token is correct

### Database issues
- The bot uses SQLite (file-based), no external database needed
- Database file (`bot.db`) is created automatically
- Make sure directory is writable

## 🔒 Security Best Practices

1. **Never commit your bot token to version control**
2. **Keep `config.json` in `.gitignore`**
3. **Use strong permissions in Discord server**
4. **Regularly rotate your bot token**
5. **Monitor bot logs for suspicious activity**

## 📁 Files to Include in Deployment

### Required Files:
- `main.py` - Main bot file
- `database.py` - Database management
- `cogs/` folder - All command modules
- `utils/` folder - Helper utilities

### Optional Files:
- `keep_alive.py` - For uptime monitoring (Replit-specific)
- `setup.py` - Setup helper script
- `README.md` - Documentation
- `DEPLOYMENT.md` - This guide

### Auto-Generated Files (don't include):
- `config.json` - Created on first run
- `bot.db` - Database file
- `bot.log` - Log file
- `__pycache__/` - Python cache

## 🌐 Making It Portable

The bot is designed to be platform-agnostic:
- No hardcoded paths
- No platform-specific dependencies
- Self-configuring on first run
- Graceful error handling
- Cross-platform file operations

## 📞 Support

If deployment fails:
1. Check Python version (3.8+ required)
2. Verify all files were uploaded
3. Check platform-specific logs
4. Ensure bot token is valid
5. Confirm Discord permissions are correct

---

**Ready to deploy?** Just run `python main.py` on any platform and follow the prompts!