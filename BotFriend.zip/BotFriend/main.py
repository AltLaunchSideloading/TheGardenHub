import discord
from discord.ext import commands
import asyncio
import json
import os
import logging
import sys

# Try to import database module, create inline if not available
try:
    from database import init_db
except ImportError:
    # Inline database initialization for platform compatibility
    import sqlite3
    async def init_db():
        """Initialize database with required tables"""
        conn = sqlite3.connect('bot.db')
        cursor = conn.cursor()
        
        # Create tables
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS warnings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                guild_id INTEGER NOT NULL,
                moderator_id INTEGER NOT NULL,
                reason TEXT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS tickets (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                channel_id INTEGER UNIQUE NOT NULL,
                user_id INTEGER NOT NULL,
                guild_id INTEGER NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                closed_at DATETIME,
                status TEXT DEFAULT 'open'
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS giveaways (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                message_id INTEGER UNIQUE NOT NULL,
                channel_id INTEGER NOT NULL,
                guild_id INTEGER NOT NULL,
                title TEXT NOT NULL,
                description TEXT,
                winners INTEGER DEFAULT 1,
                end_time DATETIME NOT NULL,
                created_by INTEGER NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                ended BOOLEAN DEFAULT FALSE
            )
        ''')
        
        conn.commit()
        conn.close()
        print("✅ Database initialized successfully")

# Try to import keep_alive, create inline if not available
try:
    from keep_alive import keep_alive
except ImportError:
    # Inline keep_alive for platform compatibility
    def keep_alive():
        """Simple keep alive function for platform compatibility"""
        try:
            from flask import Flask
            import threading
            
            app = Flask('')
            
            @app.route('/')
            def home():
                return "Discord Bot is running!"
            
            def run():
                app.run(host='0.0.0.0', port=8080, debug=False, use_reloader=False)
            
            server = threading.Thread(target=run)
            server.daemon = True
            server.start()
            print("✅ Keep-alive server started on port 8080")
        except ImportError:
            print("⚠️  Flask not available, running without keep-alive server")
            pass

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('bot.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class DiscordBot(commands.Bot):
    def __init__(self):
        # Load configuration
        try:
            with open('config.json', 'r') as f:
                self.config = json.load(f)
        except FileNotFoundError:
            logger.error("config.json not found. Creating default configuration.")
            self.create_default_config()
            with open('config.json', 'r') as f:
                self.config = json.load(f)

        # Set up intents
        intents = discord.Intents.default()
        intents.message_content = True
        intents.guilds = True
        intents.members = True

        super().__init__(
            command_prefix='!',  # Not used since we're using slash commands only
            intents=intents,
            help_command=None
        )

    def create_default_config(self):
        """Create a default configuration file"""
        default_config = {
            "bot_token": "YOUR_BOT_TOKEN",
            "guild_ids": [],
            "mod_role_name": "Moderator",
            "admin_role_name": "Admin",
            "log_channel_name": "mod-logs",
            "ticket_category_name": "Support Tickets",
            "ticket_log_channel": "ticket-logs"
        }
        with open('config.json', 'w') as f:
            json.dump(default_config, f, indent=4)
        logger.info("Created default config.json. Please configure it before running the bot.")

    async def setup_hook(self):
        """Load cogs and sync commands"""
        # Initialize database
        await init_db()

        # Load cogs
        cogs = ['cogs.moderation', 'cogs.tickets', 'cogs.utilities', 'cogs.giveaways', 'cogs.autoroles', 'cogs.logging']
        for cog in cogs:
            try:
                await self.load_extension(cog)
                logger.info(f"Loaded {cog}")
            except Exception as e:
                logger.error(f"Failed to load {cog}: {e}")

        # Sync slash commands
        try:
            synced = await self.tree.sync()
            logger.info(f"Synced {len(synced)} command(s)")
        except Exception as e:
            logger.error(f"Failed to sync commands: {e}")

    async def on_ready(self):
        """Called when the bot is ready"""
        logger.info(f"{self.user} has connected to Discord!")
        logger.info(f"Bot is in {len(self.guilds)} guilds")

    async def on_command_error(self, ctx, error):
        """Global error handler"""
        if isinstance(error, commands.MissingPermissions):
            await ctx.send("❌ You don't have permission to use this command.")
        elif isinstance(error, commands.BotMissingPermissions):
            await ctx.send("❌ I don't have the required permissions to execute this command.")
        else:
            logger.error(f"Unhandled error: {error}")

# ===== PUT YOUR BOT TOKEN HERE =====
BOT_TOKEN = "MTQwMzgwODcyMDM3ODM5Njc3Mg.GYbRv2.mdgBX8LLkwP37CgF2d1YV-_VJNo7-VIJWKmI94"  # Replace with your actual Discord bot token
# ====================================

def get_bot_token():
    """Get bot token from code, config, or prompt user"""
    # First check if token is set in code
    if BOT_TOKEN and BOT_TOKEN != "YOUR_BOT_TOKEN":
        print("✅ Using bot token from code")
        return BOT_TOKEN
    
    # Then try to get from config file
    try:
        with open('config.json', 'r') as f:
            config = json.load(f)
            token = config.get('bot_token')
            if token and token != "YOUR_BOT_TOKEN":
                print("✅ Using bot token from config.json")
                return token
    except FileNotFoundError:
        pass
    
    # If no valid token found anywhere, prompt user
    print("\n" + "="*50)
    print("🤖 DISCORD BOT SETUP")
    print("="*50)
    print("No valid bot token found!")
    print("\nYou can set your token in one of these ways:")
    print("1. Edit main.py and replace BOT_TOKEN = 'YOUR_BOT_TOKEN'")
    print("2. Enter it below (will be saved to config.json)")
    print("\nTo get your bot token:")
    print("• Go to https://discord.com/developers/applications")
    print("• Create a new application or select existing one")
    print("• Go to 'Bot' section and copy the token")
    print("\nIMPORTANT: Keep your token secret!")
    print("-"*50)
    
    while True:
        token = input("Enter your Discord bot token (or press Enter to exit): ").strip()
        if not token:
            print("❌ Exiting without token")
            return None
        if token:
            # Save token to config file
            try:
                with open('config.json', 'r') as f:
                    config = json.load(f)
            except FileNotFoundError:
                config = {
                    "bot_token": "YOUR_BOT_TOKEN",
                    "guild_ids": [],
                    "mod_role_name": "Moderator",
                    "admin_role_name": "Admin",
                    "log_channel_name": "mod-logs",
                    "ticket_category_name": "Support Tickets",
                    "ticket_log_channel": "ticket-logs"
                }
            
            config['bot_token'] = token
            with open('config.json', 'w') as f:
                json.dump(config, f, indent=4)
            print("✅ Token saved to config.json for future use")
            return token

async def main():
    """Main function to run the bot"""
    # Start the Flask server for UptimeRobot
    keep_alive()
    
    bot = DiscordBot()

    # Get bot token (will prompt if needed)
    token = get_bot_token()
    
    if not token:
        logger.error("No bot token provided. Exiting.")
        return

    try:
        print(f"🚀 Starting Discord bot...")
        await bot.start(token)
    except discord.LoginFailure:
        logger.error("❌ Invalid bot token. Please check your token and try again.")
        # Remove invalid token from config if it exists there
        try:
            with open('config.json', 'r') as f:
                config = json.load(f)
            config['bot_token'] = "YOUR_BOT_TOKEN"
            with open('config.json', 'w') as f:
                json.dump(config, f, indent=4)
            print("Invalid token removed from config.json.")
        except:
            pass
        print("Please update the BOT_TOKEN in main.py or restart to enter a new token.")
    except Exception as e:
        logger.error(f"❌ Error starting bot: {e}")

if __name__ == "__main__":
    asyncio.run(main())