#!/usr/bin/env python3
"""
Discord Bot Setup Script
Helps users set up the bot on any platform
"""

import json
import os
import sys

def print_banner():
    print("\n" + "="*60)
    print("🤖 DISCORD MODERATION BOT SETUP")
    print("="*60)
    print("This script will help you configure your Discord bot")
    print("for any platform (Replit, Heroku, Local, etc.)")
    print("-"*60)

def check_dependencies():
    """Check if required packages are installed"""
    print("\n📋 Checking dependencies...")
    
    required_packages = ['discord', 'aiosqlite']
    missing_packages = []
    
    for package in required_packages:
        try:
            __import__(package)
            print(f"✅ {package} is installed")
        except ImportError:
            print(f"❌ {package} is missing")
            missing_packages.append(package)
    
    if missing_packages:
        print(f"\n⚠️  Missing packages: {', '.join(missing_packages)}")
        print("Please install them using:")
        print("pip install discord.py python-dotenv aiosqlite")
        return False
    
    print("✅ All dependencies are installed")
    return True

def create_config():
    """Create or update configuration file"""
    print("\n⚙️  Setting up configuration...")
    
    config = {
        "_comment": "Configuration for Discord Moderation Bot",
        "bot_token": "YOUR_BOT_TOKEN",
        "guild_ids": [],
        "mod_role_name": "Moderator",
        "admin_role_name": "Admin", 
        "log_channel_name": "mod-logs",
        "ticket_category_name": "Support Tickets",
        "ticket_log_channel": "ticket-logs",
        "_setup_instructions": "Run 'python main.py' to start the bot. It will prompt for your Discord bot token."
    }
    
    # Check if config already exists
    if os.path.exists('config.json'):
        try:
            with open('config.json', 'r') as f:
                existing_config = json.load(f)
            
            # Preserve existing token if it's not the placeholder
            if existing_config.get('bot_token') != 'YOUR_BOT_TOKEN':
                config['bot_token'] = existing_config.get('bot_token', 'YOUR_BOT_TOKEN')
            
            print("✅ Updated existing config.json")
        except json.JSONDecodeError:
            print("⚠️  Existing config.json was invalid, creating new one")
    else:
        print("✅ Created new config.json")
    
    with open('config.json', 'w') as f:
        json.dump(config, f, indent=4)

def show_instructions():
    """Show setup instructions"""
    print("\n" + "="*60)
    print("🚀 SETUP COMPLETE!")
    print("="*60)
    print("\nNext steps:")
    print("1. Create a Discord bot at: https://discord.com/developers/applications")
    print("2. Copy your bot token")
    print("3. Run: python main.py")
    print("4. Enter your bot token when prompted")
    print("\nYour bot will be ready to use!")
    print("\n📁 Files created:")
    print("   - config.json (configuration)")
    print("   - README.md (documentation)")
    print("\n💡 Tips:")
    print("   - Keep your bot token secret")
    print("   - Make sure bot has Administrator permissions")
    print("   - Create the required channels/roles in your Discord server")
    print("-"*60)

def main():
    """Main setup function"""
    print_banner()
    
    # Check Python version
    if sys.version_info < (3, 8):
        print("❌ Python 3.8 or higher is required")
        print(f"   Current version: {sys.version}")
        return False
    
    print(f"✅ Python {sys.version_info.major}.{sys.version_info.minor} detected")
    
    # Check dependencies
    if not check_dependencies():
        return False
    
    # Create configuration
    create_config()
    
    # Show instructions
    show_instructions()
    
    return True

if __name__ == "__main__":
    try:
        success = main()
        if success:
            print("\n🎉 Setup completed successfully!")
        else:
            print("\n❌ Setup failed. Please fix the issues above and try again.")
    except KeyboardInterrupt:
        print("\n\n⚠️  Setup cancelled by user")
    except Exception as e:
        print(f"\n❌ An error occurred during setup: {e}")
        print("Please check the error and try again.")