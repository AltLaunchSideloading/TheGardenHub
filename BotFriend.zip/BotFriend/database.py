import sqlite3
import asyncio
import logging
from datetime import datetime

logger = logging.getLogger(__name__)

class Database:
    def __init__(self, db_path='bot.db'):
        self.db_path = db_path
        self.connection = None

    async def connect(self):
        """Connect to the database"""
        self.connection = sqlite3.connect(self.db_path)
        self.connection.row_factory = sqlite3.Row
        return self.connection

    async def disconnect(self):
        """Disconnect from the database"""
        if self.connection:
            self.connection.close()

    async def execute(self, query, params=None):
        """Execute a query"""
        if not self.connection:
            await self.connect()
        
        cursor = self.connection.cursor()
        if params:
            cursor.execute(query, params)
        else:
            cursor.execute(query)
        self.connection.commit()
        return cursor

    async def fetchone(self, query, params=None):
        """Fetch one row"""
        cursor = await self.execute(query, params)
        return cursor.fetchone()

    async def fetchall(self, query, params=None):
        """Fetch all rows"""
        cursor = await self.execute(query, params)
        return cursor.fetchall()

# Global database instance
db = Database()

async def init_db():
    """Initialize the database with required tables"""
    await db.connect()
    
    # Create tickets table
    await db.execute('''
        CREATE TABLE IF NOT EXISTS tickets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            guild_id INTEGER NOT NULL,
            channel_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            moderator_id INTEGER,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            closed_at TIMESTAMP,
            status TEXT DEFAULT 'open',
            subject TEXT,
            transcript TEXT
        )
    ''')
    
    # Create moderation actions table
    await db.execute('''
        CREATE TABLE IF NOT EXISTS moderation_actions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            guild_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            moderator_id INTEGER NOT NULL,
            action_type TEXT NOT NULL,
            reason TEXT,
            duration INTEGER,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    logger.info("Database initialized successfully")

async def create_ticket(guild_id, channel_id, user_id, subject=None):
    """Create a new ticket"""
    await db.execute(
        'INSERT INTO tickets (guild_id, channel_id, user_id, subject) VALUES (?, ?, ?, ?)',
        (guild_id, channel_id, user_id, subject)
    )
    
    # Get the ticket ID
    result = await db.fetchone('SELECT last_insert_rowid() as id')
    return result['id']

async def get_ticket_by_channel(channel_id):
    """Get ticket by channel ID"""
    return await db.fetchone('SELECT * FROM tickets WHERE channel_id = ? AND status = "open"', (channel_id,))

async def close_ticket(ticket_id, moderator_id, transcript=None):
    """Close a ticket"""
    await db.execute(
        'UPDATE tickets SET status = "closed", closed_at = CURRENT_TIMESTAMP, moderator_id = ?, transcript = ? WHERE id = ?',
        (moderator_id, transcript, ticket_id)
    )

async def log_moderation_action(guild_id, user_id, moderator_id, action_type, reason=None, duration=None):
    """Log a moderation action"""
    await db.execute(
        'INSERT INTO moderation_actions (guild_id, user_id, moderator_id, action_type, reason, duration) VALUES (?, ?, ?, ?, ?, ?)',
        (guild_id, user_id, moderator_id, action_type, reason, duration)
    )
