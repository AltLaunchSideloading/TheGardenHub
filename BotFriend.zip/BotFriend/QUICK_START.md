# Quick Start Guide - 30 Seconds Setup! 🚀

## Super Easy Setup (No prompts needed!)

1. **Get your Discord bot token**:
   - Go to https://discord.com/developers/applications
   - Create new application → Bot section → Copy token

2. **Put token in code**:
   - Open `main.py`
   - Find line 99: `BOT_TOKEN = "YOUR_BOT_TOKEN"`
   - Replace with: `BOT_TOKEN = "your_actual_token_here"`

3. **Run the bot**:
   ```bash
   python main.py
   ```

**That's it!** Your bot is now running on ANY platform.

## Example

**Before (line 99 in main.py):**
```python
BOT_TOKEN = "YOUR_BOT_TOKEN"  # Replace with your actual Discord bot token
```

**After:**
```python
BOT_TOKEN = "MTIwNzY4ODk5OTczNDQ2NjU3MA.GXX7Ew.actual_token_here"  # Replace with your actual Discord bot token
```

## Works everywhere!
- ✅ Export as .zip → Upload to any hosting platform
- ✅ No environment variables needed
- ✅ No secret setup required
- ✅ Runs immediately on any Python-supporting platform

---
**Need help?** Check README.md for full documentation!