# 24/7 Bot Hosting with UptimeRobot

Your Discord bot is now configured to run 24/7 using UptimeRobot monitoring.

## How it Works

1. **Flask Server**: A lightweight web server runs alongside your bot on port 8080
2. **Health Endpoints**: UptimeRobot can ping these endpoints to keep your bot alive
3. **No Bot Impact**: This runs in a separate thread and doesn't affect bot performance

## Available Endpoints

- `http://your-replit-url.replit.dev/` - Shows "Discord Bot is running! 🤖"
- `http://your-replit-url.replit.dev/ping` - Returns "pong"
- `http://your-replit-url.replit.dev/status` - Returns JSON status info

## UptimeRobot Setup

1. **Your Replit URL**: `https://c4814c9a-58ed-49d2-b370-1d22ccb8c7ba-00-qad5swt4ha3t.riker.replit.dev/ping`
2. **Create UptimeRobot Account**: Go to uptimerobot.com and sign up (free plan works perfectly)
3. **Add New Monitor**:
   - Monitor Type: HTTP(s)
   - Friendly Name: "Discord Bot"
   - URL: `https://c4814c9a-58ed-49d2-b370-1d22ccb8c7ba-00-qad5swt4ha3t.riker.replit.dev/ping`
   - Monitoring Interval: 5 minutes (or less for faster response)
4. **Save**: UptimeRobot will now ping your bot every 5 minutes to keep it alive

## Benefits

- Keeps your Replit always active
- Prevents bot from going offline due to inactivity
- Free monitoring with UptimeRobot's free plan
- Automatic restart notifications if bot goes down

## Notes

- The Flask server uses minimal resources
- All Discord bot functionality remains unchanged
- You can still use your bot normally while monitoring is active