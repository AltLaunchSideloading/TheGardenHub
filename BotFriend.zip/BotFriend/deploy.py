#!/usr/bin/env python3
"""
Deployment preparation script for Discord Bot
Cleans up files and prepares for deployment on any platform
"""

import os
import shutil
import json

def clean_cache_files():
    """Remove Python cache files that can cause deployment issues"""
    print("🧹 Cleaning cache files...")
    
    # Remove __pycache__ directories
    for root, dirs, files in os.walk('.'):
        for dir_name in dirs:
            if dir_name == '__pycache__':
                cache_path = os.path.join(root, dir_name)
                shutil.rmtree(cache_path)
                print(f"   Removed: {cache_path}")
    
    # Remove .pyc files
    for root, dirs, files in os.walk('.'):
        for file in files:
            if file.endswith('.pyc'):
                pyc_path = os.path.join(root, file)
                os.remove(pyc_path)
                print(f"   Removed: {pyc_path}")

def create_minimal_requirements():
    """Create a simple requirements.txt for deployment"""
    requirements = [
        "discord.py>=2.5.0",
        "aiosqlite>=0.19.0"
    ]
    
    with open('requirements_deploy.txt', 'w') as f:
        f.write('\n'.join(requirements))
    
    print("✅ Created requirements_deploy.txt")

def verify_main_file():
    """Check that main.py has the inline imports for deployment"""
    with open('main.py', 'r') as f:
        content = f.read()
    
    if 'try:\n    from database import init_db\nexcept ImportError:' in content:
        print("✅ main.py has inline database fallback")
    else:
        print("❌ main.py missing inline database fallback")
    
    if 'try:\n    from keep_alive import keep_alive\nexcept ImportError:' in content:
        print("✅ main.py has inline keep_alive fallback")
    else:
        print("❌ main.py missing inline keep_alive fallback")

def create_deployment_files():
    """Create platform-specific deployment files"""
    
    # Procfile for Heroku
    with open('Procfile', 'w') as f:
        f.write('worker: python main.py\n')
    print("✅ Created Procfile for Heroku")
    
    # Railway start command
    railway_config = {
        "build": {
            "builder": "NIXPACKS"
        },
        "deploy": {
            "startCommand": "python main.py"
        }
    }
    
    with open('railway.json', 'w') as f:
        json.dump(railway_config, f, indent=2)
    print("✅ Created railway.json")

def show_deployment_tips():
    """Show deployment tips for different platforms"""
    print("\n" + "="*50)
    print("🚀 DEPLOYMENT READY!")
    print("="*50)
    print("\nPlatform-specific tips:")
    print("\n📋 For pella.app:")
    print("   • Make sure BOT_TOKEN is set in main.py (line 139)")
    print("   • Upload all files except __pycache__ folders")
    print("   • Set start command to: python main.py")
    
    print("\n📋 For Heroku:")
    print("   • Use the included Procfile")
    print("   • Deploy from git repository")
    
    print("\n📋 For Railway:")
    print("   • Use the included railway.json")
    print("   • Connect your GitHub repository")
    
    print("\n📋 For any platform:")
    print("   • Dependencies: discord.py>=2.5.0, aiosqlite>=0.19.0")
    print("   • Start command: python main.py")
    print("   • Make sure BOT_TOKEN is set in main.py")
    
    print("\n" + "-"*50)

def main():
    """Main deployment preparation function"""
    print("🔧 Preparing Discord Bot for deployment...")
    
    clean_cache_files()
    create_minimal_requirements()
    verify_main_file()
    create_deployment_files()
    show_deployment_tips()
    
    print("\n🎉 Bot is ready for deployment on any platform!")

if __name__ == "__main__":
    main()