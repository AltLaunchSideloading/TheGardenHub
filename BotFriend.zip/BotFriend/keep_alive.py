from flask import Flask
from threading import Thread
import time

app = Flask('')

@app.route('/')
def home():
    return "Discord Bot is running! 🤖"

@app.route('/ping')
def ping():
    return "pong"

@app.route('/status')
def status():
    return {
        "status": "online",
        "message": "Discord bot is healthy and running",
        "timestamp": time.time()
    }

def run():
    app.run(host='0.0.0.0', port=8080)

def keep_alive():
    t = Thread(target=run)
    t.daemon = True
    t.start()