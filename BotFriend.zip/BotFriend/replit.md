# Discord Moderation Bot

## Overview

This is a Discord moderation bot built with discord.py that provides comprehensive server management capabilities. The bot features a modular cog-based architecture with slash commands for moderation actions, ticket support systems, and utility functions. It uses SQLite for data persistence and includes role-based permission systems for secure operation.

## User Preferences

Preferred communication style: Simple, everyday language.
Portability: Make code work across different platforms without platform-specific dependencies or secrets.

## System Architecture

### Application Structure
- **Modular Design**: Bot functionality is organized into separate cogs (moderation, tickets, utilities) for maintainability and scalability
- **Command System**: Exclusively uses Discord's slash commands for modern user interaction
- **Configuration Management**: JSON-based configuration system for flexible deployment across different servers
- **Interactive Setup**: Bot prompts for Discord token on first run, no environment variables required
- **Platform Agnostic**: Works on any Python-supporting platform without modifications

### Database Layer
- **SQLite Integration**: Uses SQLite as the primary database with a custom async wrapper class
- **Connection Management**: Implements connection pooling and automatic reconnection handling
- **Data Persistence**: Stores moderation logs, ticket information, and user data

### Permission System
- **Role-Based Access**: Implements hierarchical permission checking based on Discord roles and server permissions
- **Configurable Roles**: Admin and moderator roles can be customized per server
- **Permission Validation**: Built-in checks prevent privilege escalation and unauthorized actions

### User Interface
- **Interactive Components**: Uses Discord's UI components like buttons and modals for enhanced user experience
- **Embed System**: Standardized embed creation for consistent visual presentation
- **Error Handling**: Comprehensive error messages with user-friendly feedback

### Core Features
- **Moderation Tools**: Kick, ban, timeout, warning, and purge systems with comprehensive logging
- **Advanced Logging**: Tracks role updates, name changes, avatar changes, bans/unbans, timeouts, message edits/deletes, member joins/leaves
- **Ticket System**: Open ticket creation for all users with staff management tools
- **Auto-Role Assignment**: Automatically assigns 5 roles to new members upon joining
- **Role-Based Permissions**: Restricted moderation access to specific role ID (1403035790602272798)
- **Centralized Logging**: All moderation, ticket, and member events log to channel ID (1403035407913848883)
- **Utility Commands**: Server information, user lookup, and administrative tools
- **24/7 Hosting**: UptimeRobot integration with Flask health server on port 8080

## External Dependencies

### Discord Integration
- **discord.py**: Primary library for Discord API interaction and bot functionality
- **Discord Gateway**: Real-time event handling for message and user events
- **Slash Commands**: Modern command interface using Discord's application commands

### Database
- **SQLite3**: Embedded database for local data storage and persistence
- **Python sqlite3 module**: Built-in database connectivity and query execution

### System Dependencies
- **Python Logging**: Comprehensive logging system for debugging and monitoring
- **JSON**: Configuration file parsing and data serialization
- **Asyncio**: Asynchronous programming support for concurrent operations
- **Datetime**: Time-based operations for logging and scheduling

### File System
- **Configuration Files**: JSON-based configuration management
- **Log Files**: File-based logging for persistent error tracking and debugging