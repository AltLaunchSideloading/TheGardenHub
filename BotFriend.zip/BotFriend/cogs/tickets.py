import discord
from discord.ext import commands
from discord import app_commands
import json
import logging
from datetime import datetime
from utils.embeds import create_embed, create_error_embed
from utils.permissions import log_ticket_action, has_mod_permissions
from database import create_ticket, get_ticket_by_channel, close_ticket

logger = logging.getLogger(__name__)

class TicketCreateView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Create Ticket", style=discord.ButtonStyle.primary, emoji="🎫", custom_id="create_ticket")
    async def create_ticket_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Handle ticket creation button"""
        await interaction.response.send_modal(TicketModal())

class TicketModal(discord.ui.Modal, title="Create Support Ticket"):
    def __init__(self):
        super().__init__()

    subject = discord.ui.TextInput(
        label="Subject",
        placeholder="Brief description of your issue...",
        max_length=100,
        required=True
    )

    description = discord.ui.TextInput(
        label="Description",
        placeholder="Please provide detailed information about your issue...",
        style=discord.TextStyle.paragraph,
        max_length=1000,
        required=True
    )

    async def on_submit(self, interaction: discord.Interaction):
        """Handle modal submission"""
        cog = interaction.client.get_cog('Tickets')
        if cog:
            await cog.create_ticket_channel(interaction, self.subject.value, self.description.value)

class TicketControlView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Close Ticket", style=discord.ButtonStyle.danger, emoji="🔒", custom_id="close_ticket")
    async def close_ticket_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Handle ticket closure"""
        cog = interaction.client.get_cog('Tickets')
        if cog:
            await cog.close_ticket_channel(interaction)

    @discord.ui.button(label="Claim Ticket", style=discord.ButtonStyle.success, emoji="✋", custom_id="claim_ticket")
    async def claim_ticket_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Handle ticket claiming"""
        cog = interaction.client.get_cog('Tickets')
        if cog:
            await cog.claim_ticket_channel(interaction)

class Tickets(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        
    async def get_config(self):
        """Get bot configuration"""
        try:
            with open('config.json', 'r') as f:
                return json.load(f)
        except:
            return {}

    async def get_ticket_category(self, guild):
        """Get or create the ticket category"""
        config = await self.get_config()
        category_name = config.get('ticket_category_name', 'Support Tickets')
        
        category = discord.utils.get(guild.categories, name=category_name)
        if not category:
            try:
                category = await guild.create_category(
                    category_name,
                    reason="Creating ticket category"
                )
            except discord.Forbidden:
                return None
        return category

    async def get_ticket_log_channel(self, guild):
        """Get the ticket log channel"""
        config = await self.get_config()
        channel_name = config.get('ticket_log_channel', 'ticket-logs')
        return discord.utils.get(guild.channels, name=channel_name)

    @app_commands.command(name="ticket-setup", description="Setup the ticket system in this channel")
    async def ticket_setup(self, interaction: discord.Interaction):
        """Setup ticket system"""
        if not interaction.user.guild_permissions.administrator:
            embed = create_error_embed("Permission Denied", "You need administrator permissions to use this command.")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        embed = create_embed(
            "🎫 Support Tickets",
            "Need help? Click the button below to create a support ticket!\n\n"
            "**What to include:**\n"
            "• Clear description of your issue\n"
            "• Any relevant screenshots or information\n"
            "• Steps you've already tried\n\n"
            "Our support team will assist you as soon as possible.",
            color=discord.Color.blue()
        )
        embed.set_footer(text="Click the button below to create a ticket")

        view = TicketCreateView()
        await interaction.response.send_message(embed=embed, view=view)

    async def create_ticket_channel(self, interaction: discord.Interaction, subject: str, description: str):
        """Create a new ticket channel"""
        # Check if user already has an open ticket
        existing_ticket = None
        for channel in interaction.guild.text_channels:
            if channel.name.startswith(f"ticket-{interaction.user.name.lower()}"):
                existing_ticket_data = await get_ticket_by_channel(channel.id)
                if existing_ticket_data:
                    existing_ticket = channel
                    break

        if existing_ticket:
            embed = create_error_embed("Ticket Exists", f"You already have an open ticket: {existing_ticket.mention}")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        try:
            # Get ticket category
            category = await self.get_ticket_category(interaction.guild)
            
            # Create channel name
            channel_name = f"ticket-{interaction.user.name.lower()}-{interaction.user.discriminator}"
            
            # Set up permissions
            overwrites = {
                interaction.guild.default_role: discord.PermissionOverwrite(read_messages=False),
                interaction.user: discord.PermissionOverwrite(read_messages=True, send_messages=True),
                interaction.guild.me: discord.PermissionOverwrite(read_messages=True, send_messages=True)
            }

            # Add moderator role permissions
            config = await self.get_config()
            mod_role_id = config.get('mod_role_id')
            admin_role_id = config.get('admin_role_id')
            
            # Add role by ID first, then fallback to name
            if mod_role_id:
                mod_role = interaction.guild.get_role(mod_role_id)
                if mod_role:
                    overwrites[mod_role] = discord.PermissionOverwrite(read_messages=True, send_messages=True)
            
            if admin_role_id:
                admin_role = interaction.guild.get_role(admin_role_id)
                if admin_role:
                    overwrites[admin_role] = discord.PermissionOverwrite(read_messages=True, send_messages=True)
            
            # Fallback to role names if IDs not configured
            if not mod_role_id:
                mod_role_name = config.get('mod_role_name', 'Moderator')
                mod_role = discord.utils.get(interaction.guild.roles, name=mod_role_name)
                if mod_role:
                    overwrites[mod_role] = discord.PermissionOverwrite(read_messages=True, send_messages=True)
                    
            if not admin_role_id:
                admin_role_name = config.get('admin_role_name', 'Admin')
                admin_role = discord.utils.get(interaction.guild.roles, name=admin_role_name)
                if admin_role:
                    overwrites[admin_role] = discord.PermissionOverwrite(read_messages=True, send_messages=True)

            # Create the channel
            ticket_channel = await interaction.guild.create_text_channel(
                channel_name,
                category=category,
                overwrites=overwrites,
                topic=f"Support ticket for {interaction.user} | Subject: {subject}"
            )

            # Create ticket in database
            ticket_id = await create_ticket(
                interaction.guild.id,
                ticket_channel.id,
                interaction.user.id,
                subject
            )

            # Create ticket embed
            ticket_embed = create_embed(
                f"🎫 Ticket #{ticket_id:04d}",
                f"**Subject:** {subject}\n**Description:**\n{description}\n\n**Created by:** {interaction.user.mention}",
                color=discord.Color.green()
            )
            ticket_embed.set_footer(text=f"Ticket ID: {ticket_id} | Created: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

            # Send ticket message with controls
            view = TicketControlView()
            await ticket_channel.send(
                f"👋 Welcome {interaction.user.mention}! Your ticket has been created.",
                embed=ticket_embed,
                view=view
            )

            # Confirm creation (ephemeral so it doesn't show as a reply)
            embed = create_embed(
                "🎫 Ticket Created Successfully",
                f"Your support ticket has been created: {ticket_channel.mention}\n\nPlease head over to your ticket channel to describe your issue in detail.",
                color=discord.Color.green()
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)

            # Log ticket creation
            await log_ticket_action(
                interaction.guild, "create", interaction.user, ticket_channel, subject
            )

        except discord.Forbidden:
            embed = create_error_embed("Permission Error", "I don't have permission to create channels.")
            await interaction.response.send_message(embed=embed, ephemeral=True)
        except Exception as e:
            embed = create_error_embed("Error", f"Failed to create ticket: {str(e)}")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            logger.error(f"Ticket creation error: {e}")

    async def close_ticket_channel(self, interaction: discord.Interaction):
        """Close a ticket channel"""
        # Check if this is a ticket channel
        ticket_data = await get_ticket_by_channel(interaction.channel.id)
        if not ticket_data:
            embed = create_error_embed("Not a Ticket", "This command can only be used in ticket channels.")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        # Check permissions - moderators or ticket creator can close
        has_permission = (
            await has_mod_permissions(interaction.user, interaction.guild) or
            interaction.user.id == ticket_data['user_id']
        )

        if not has_permission:
            embed = create_error_embed("Permission Denied", "You don't have permission to close this ticket.")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        try:
            # Generate transcript (simplified)
            messages = []
            async for message in interaction.channel.history(limit=100, oldest_first=True):
                if not message.author.bot:
                    timestamp = message.created_at.strftime('%Y-%m-%d %H:%M:%S')
                    messages.append(f"[{timestamp}] {message.author}: {message.content}")
            
            transcript = "\n".join(messages)

            # Close ticket in database
            await close_ticket(ticket_data['id'], interaction.user.id, transcript)

            # Send closure confirmation
            embed = create_embed(
                "🔒 Ticket Closed",
                f"This ticket has been closed by {interaction.user.mention}.\nThe channel will be deleted in 10 seconds.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed)

            # Log ticket closure
            await log_ticket_action(
                interaction.guild, "close", interaction.user, interaction.channel, moderator=interaction.user
            )

            # Delete channel after delay
            import asyncio
            await asyncio.sleep(10)
            await interaction.channel.delete(reason=f"Ticket closed by {interaction.user}")

        except Exception as e:
            embed = create_error_embed("Error", f"Failed to close ticket: {str(e)}")
            await interaction.followup.send(embed=embed, ephemeral=True)
            logger.error(f"Ticket closure error: {e}")

    async def claim_ticket_channel(self, interaction: discord.Interaction):
        """Claim a ticket"""
        # Check if this is a ticket channel
        ticket_data = await get_ticket_by_channel(interaction.channel.id)
        if not ticket_data:
            embed = create_error_embed("Not a Ticket", "This command can only be used in ticket channels.")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        # Check permissions - only moderators can claim tickets
        has_permission = await has_mod_permissions(interaction.user, interaction.guild)

        if not has_permission:
            embed = create_error_embed("Permission Denied", "You don't have permission to claim tickets.")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        embed = create_embed(
            "✋ Ticket Claimed",
            f"This ticket has been claimed by {interaction.user.mention}.",
            color=discord.Color.blue()
        )
        await interaction.response.send_message(embed=embed)
        
        # Log ticket claim
        await log_ticket_action(
            interaction.guild, "claim", interaction.user, interaction.channel, moderator=interaction.user
        )

    @commands.Cog.listener()
    async def on_ready(self):
        """Add persistent views when bot starts"""
        self.bot.add_view(TicketCreateView())
        self.bot.add_view(TicketControlView())

async def setup(bot):
    await bot.add_cog(Tickets(bot))
