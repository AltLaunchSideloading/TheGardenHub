import discord
from discord.ext import commands
import json
import logging
from utils.embeds import create_embed
from datetime import datetime

logger = logging.getLogger(__name__)

class Logging(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        
    async def get_config(self):
        """Get bot configuration"""
        try:
            with open('config.json', 'r') as f:
                return json.load(f)
        except:
            return {}

    async def log_to_channel(self, guild, embed):
        """Send log embed to the configured log channel"""
        try:
            config = await self.get_config()
            log_channel_id = config.get('log_channel_id')
            
            logger.info(f"Attempting to log to channel {log_channel_id}")
            
            if log_channel_id:
                log_channel = guild.get_channel(log_channel_id)
                if log_channel and hasattr(log_channel, 'send'):
                    await log_channel.send(embed=embed)
                    logger.info(f"Successfully sent log to {log_channel.name}")
                else:
                    logger.warning(f"Could not find log channel {log_channel_id} or channel lacks send permission")
            else:
                logger.warning("No log_channel_id configured")
        except Exception as e:
            logger.error(f"Error sending log: {e}")

    @commands.Cog.listener()
    async def on_member_update(self, before: discord.Member, after: discord.Member):
        """Log member updates (roles, nicknames, avatar changes)"""
        try:
            # Role changes
            if before.roles != after.roles:
                added_roles = [role for role in after.roles if role not in before.roles]
                removed_roles = [role for role in before.roles if role not in after.roles]
                
                if added_roles or removed_roles:
                    description = f"**User:** {after.mention} ({after})\n**User ID:** {after.id}\n"
                    
                    if added_roles:
                        description += f"**Roles Added:** {', '.join([role.mention for role in added_roles])}\n"
                    if removed_roles:
                        description += f"**Roles Removed:** {', '.join([role.mention for role in removed_roles])}\n"
                    
                    description += f"**Time:** <t:{int(discord.utils.utcnow().timestamp())}:F>"
                    
                    embed = create_embed(
                        "🔄 Role Update",
                        description,
                        color=0x3498DB
                    )
                    embed.set_thumbnail(url=after.display_avatar.url)
                    await self.log_to_channel(after.guild, embed)

            # Nickname changes
            if before.nick != after.nick:
                description = f"**User:** {after.mention} ({after})\n**User ID:** {after.id}\n"
                description += f"**Before:** {before.nick or 'None'}\n"
                description += f"**After:** {after.nick or 'None'}\n"
                description += f"**Time:** <t:{int(discord.utils.utcnow().timestamp())}:F>"
                
                embed = create_embed(
                    "📝 Nickname Changed",
                    description,
                    color=0xF39C12
                )
                embed.set_thumbnail(url=after.display_avatar.url)
                await self.log_to_channel(after.guild, embed)

        except Exception as e:
            logger.error(f"Error in member update logging: {e}")

    @commands.Cog.listener()
    async def on_user_update(self, before: discord.User, after: discord.User):
        """Log user updates (username, avatar changes)"""
        try:
            # Username changes
            if before.name != after.name:
                # Check if user is in any of our guilds
                for guild in self.bot.guilds:
                    member = guild.get_member(after.id)
                    if member:
                        description = f"**User:** {after.mention} ({after})\n**User ID:** {after.id}\n"
                        description += f"**Before:** {before.name}\n"
                        description += f"**After:** {after.name}\n"
                        description += f"**Time:** <t:{int(discord.utils.utcnow().timestamp())}:F>"
                        
                        embed = create_embed(
                            "👤 Username Changed",
                            description,
                            color=0x9B59B6
                        )
                        embed.set_thumbnail(url=after.display_avatar.url)
                        await self.log_to_channel(guild, embed)
                        break

            # Avatar changes
            if before.avatar != after.avatar:
                for guild in self.bot.guilds:
                    member = guild.get_member(after.id)
                    if member:
                        description = f"**User:** {after.mention} ({after})\n**User ID:** {after.id}\n"
                        description += f"**Time:** <t:{int(discord.utils.utcnow().timestamp())}:F>"
                        
                        embed = create_embed(
                            "🖼️ Avatar Changed",
                            description,
                            color=0xE67E22
                        )
                        embed.set_thumbnail(url=after.display_avatar.url)
                        if before.avatar:
                            embed.set_image(url=before.display_avatar.url)
                            embed.add_field(name="Previous Avatar", value="[Click here]("+str(before.display_avatar.url)+")", inline=False)
                        await self.log_to_channel(guild, embed)
                        break

        except Exception as e:
            logger.error(f"Error in user update logging: {e}")

    @commands.Cog.listener()
    async def on_member_ban(self, guild: discord.Guild, user: discord.User):
        """Log member bans"""
        try:
            # Try to get ban reason from audit log
            reason = "Unknown"
            moderator = "Unknown"
            
            try:
                async for entry in guild.audit_logs(action=discord.AuditLogAction.ban, limit=1):
                    if entry.target and entry.target.id == user.id:
                        reason = entry.reason or "No reason provided"
                        moderator = entry.user.mention if entry.user else "Unknown"
                        break
            except:
                pass

            description = f"**User:** {user.mention} ({user})\n**User ID:** {user.id}\n"
            description += f"**Moderator:** {moderator}\n"
            description += f"**Reason:** {reason}\n"
            description += f"**Time:** <t:{int(discord.utils.utcnow().timestamp())}:F>"
            
            embed = create_embed(
                "🔨 Member Banned",
                description,
                color=0xE74C3C
            )
            embed.set_thumbnail(url=user.display_avatar.url)
            await self.log_to_channel(guild, embed)

        except Exception as e:
            logger.error(f"Error logging ban: {e}")

    @commands.Cog.listener()
    async def on_member_unban(self, guild: discord.Guild, user: discord.User):
        """Log member unbans"""
        try:
            # Try to get unban reason from audit log
            reason = "Unknown"
            moderator = "Unknown"
            
            try:
                async for entry in guild.audit_logs(action=discord.AuditLogAction.unban, limit=1):
                    if entry.target and entry.target.id == user.id:
                        reason = entry.reason or "No reason provided"
                        moderator = entry.user.mention if entry.user else "Unknown"
                        break
            except:
                pass

            description = f"**User:** {user.mention} ({user})\n**User ID:** {user.id}\n"
            description += f"**Moderator:** {moderator}\n"
            description += f"**Reason:** {reason}\n"
            description += f"**Time:** <t:{int(discord.utils.utcnow().timestamp())}:F>"
            
            embed = create_embed(
                "🔓 Member Unbanned",
                description,
                color=0x2ECC71
            )
            embed.set_thumbnail(url=user.display_avatar.url)
            await self.log_to_channel(guild, embed)

        except Exception as e:
            logger.error(f"Error logging unban: {e}")

    @commands.Cog.listener()
    async def on_message_delete(self, message: discord.Message):
        """Log deleted messages"""
        try:
            # Ignore bot messages and DMs
            if message.author.bot or not message.guild:
                return

            description = f"**Author:** {message.author.mention} ({message.author})\n"
            if hasattr(message.channel, 'mention'):
                description += f"**Channel:** {message.channel.mention}\n"
            else:
                description += f"**Channel:** {message.channel.name}\n"
            description += f"**Message ID:** {message.id}\n"
            
            # Truncate long messages
            content = message.content[:1000] + "..." if len(message.content) > 1000 else message.content
            if content:
                description += f"**Content:**\n```{content}```\n"
            
            if message.attachments:
                description += f"**Attachments:** {len(message.attachments)} file(s)\n"
            
            description += f"**Time:** <t:{int(discord.utils.utcnow().timestamp())}:F>"
            
            embed = create_embed(
                "🗑️ Message Deleted",
                description,
                color=0xE74C3C
            )
            embed.set_thumbnail(url=message.author.display_avatar.url)
            await self.log_to_channel(message.guild, embed)

        except Exception as e:
            logger.error(f"Error logging message deletion: {e}")

    @commands.Cog.listener()
    async def on_message_edit(self, before: discord.Message, after: discord.Message):
        """Log edited messages"""
        try:
            # Ignore bot messages, DMs, and embeds
            if before.author.bot or not before.guild or before.content == after.content:
                return

            description = f"**Author:** {after.author.mention} ({after.author})\n"
            if hasattr(after.channel, 'mention'):
                description += f"**Channel:** {after.channel.mention}\n"
            else:
                description += f"**Channel:** {after.channel.name}\n"
            description += f"**Message ID:** {after.id}\n"
            description += f"**Jump to Message:** [Click here]({after.jump_url})\n"
            
            # Truncate long messages
            before_content = before.content[:500] + "..." if len(before.content) > 500 else before.content
            after_content = after.content[:500] + "..." if len(after.content) > 500 else after.content
            
            if before_content:
                description += f"**Before:**\n```{before_content}```\n"
            if after_content:
                description += f"**After:**\n```{after_content}```\n"
            
            description += f"**Time:** <t:{int(discord.utils.utcnow().timestamp())}:F>"
            
            embed = create_embed(
                "✏️ Message Edited",
                description,
                color=0xF39C12
            )
            embed.set_thumbnail(url=after.author.display_avatar.url)
            await self.log_to_channel(after.guild, embed)

        except Exception as e:
            logger.error(f"Error logging message edit: {e}")

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        """Log member joins"""
        try:
            logger.info(f"Member joined: {member} ({member.id})")
            description = f"**User:** {member.mention} ({member})\n"
            description += f"**User ID:** {member.id}\n"
            description += f"**Account Created:** <t:{int(member.created_at.timestamp())}:F>\n"
            description += f"**Time:** <t:{int(discord.utils.utcnow().timestamp())}:F>"
            
            embed = create_embed(
                "📥 Member Joined",
                description,
                color=0x2ECC71
            )
            embed.set_thumbnail(url=member.display_avatar.url)
            await self.log_to_channel(member.guild, embed)

        except Exception as e:
            logger.error(f"Error logging member join: {e}")

    @commands.Cog.listener()
    async def on_member_remove(self, member: discord.Member):
        """Log member leaves"""
        try:
            roles = [role.name for role in member.roles if role.name != '@everyone']
            
            description = f"**User:** {member.mention} ({member})\n"
            description += f"**User ID:** {member.id}\n"
            if roles:
                description += f"**Roles:** {', '.join(roles)}\n"
            description += f"**Joined:** <t:{int(member.joined_at.timestamp())}:F>\n" if member.joined_at else ""
            description += f"**Time:** <t:{int(discord.utils.utcnow().timestamp())}:F>"
            
            embed = create_embed(
                "📤 Member Left",
                description,
                color=0xE74C3C
            )
            embed.set_thumbnail(url=member.display_avatar.url)
            await self.log_to_channel(member.guild, embed)

        except Exception as e:
            logger.error(f"Error logging member leave: {e}")

async def setup(bot):
    await bot.add_cog(Logging(bot))