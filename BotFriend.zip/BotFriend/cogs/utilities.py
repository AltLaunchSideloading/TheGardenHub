import discord
from discord.ext import commands
from discord import app_commands
import logging
from utils.embeds import create_embed, create_error_embed
from utils.permissions import has_mod_permissions

logger = logging.getLogger(__name__)

class EmbedBuilderModal(discord.ui.Modal, title="Custom Embed Builder"):
    def __init__(self):
        super().__init__()

    title_input = discord.ui.TextInput(
        label="📝 Embed Title",
        placeholder="Server Announcements, Welcome Message, Rules, etc.",
        max_length=256,
        required=False
    )

    description_input = discord.ui.TextInput(
        label="📄 Main Content",
        placeholder="Welcome to our server! Please read the rules and have fun.",
        style=discord.TextStyle.paragraph,
        max_length=4000,
        required=False
    )

    color_input = discord.ui.TextInput(
        label="🎨 Embed Color",
        placeholder="green, red, blue, yellow, purple, orange, #FF5733, #00FF00",
        max_length=20,
        required=False,
        default="green"
    )

    footer_input = discord.ui.TextInput(
        label="👤 Footer Text",
        placeholder="Created by Admin Team • Server Rules • Contact Support",
        max_length=2048,
        required=False
    )

    image_url_input = discord.ui.TextInput(
        label="🖼️ Image URL (Optional)",
        placeholder="https://example.com/image.png",
        max_length=500,
        required=False
    )

    async def on_submit(self, interaction: discord.Interaction):
        """Handle embed builder modal submission"""
        # Parse color
        color = discord.Color.green()  # Default to green
        if self.color_input.value:
            color_value = self.color_input.value.lower()
            try:
                if color_value.startswith('#'):
                    color = discord.Color(int(color_value[1:], 16))
                elif color_value == 'red':
                    color = discord.Color.red()
                elif color_value == 'green':
                    color = discord.Color.green()
                elif color_value == 'blue':
                    color = discord.Color.blue()
                elif color_value == 'yellow':
                    color = discord.Color.yellow()
                elif color_value == 'purple':
                    color = discord.Color.purple()
                elif color_value == 'orange':
                    color = discord.Color.orange()
                elif color_value == 'pink':
                    color = discord.Color.magenta()
                elif color_value == 'gold':
                    color = discord.Color.gold()
                else:
                    color = discord.Color(int(color_value, 16))
            except ValueError:
                color = discord.Color.green()

        # Create embed
        embed = discord.Embed(color=color)
        
        if self.title_input.value:
            embed.title = self.title_input.value
        
        if self.description_input.value:
            embed.description = self.description_input.value
        
        if self.footer_input.value:
            embed.set_footer(text=self.footer_input.value)

        if self.image_url_input.value:
            try:
                embed.set_image(url=self.image_url_input.value)
            except:
                pass  # Invalid URL, skip image

        # Add timestamp
        embed.timestamp = discord.utils.utcnow()

        try:
            await interaction.response.send_message(embed=embed)
        except Exception as e:
            error_embed = create_error_embed("Error", f"Failed to create embed: {str(e)}")
            await interaction.response.send_message(embed=error_embed, ephemeral=True)

class Utilities(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="help", description="Display all available commands")
    async def help_command(self, interaction: discord.Interaction):
        """Help command with embed"""
        embed = create_embed(
            "🤖 Bot Commands & Features",
            "Your complete Discord moderation and utility bot with all slash commands:",
            color=discord.Color.green()
        )

        # Moderation Commands
        mod_commands = """
        `/kick <member> [reason]` - Remove a member from the server
        `/ban <member> [reason] [delete_messages]` - Permanently ban a member  
        `/mute <member> <duration> [reason]` - Temporarily timeout a member
        `/unmute <member> [reason]` - Remove timeout from a member
        `/clear <amount>` - Delete multiple messages (1-100)
        """
        embed.add_field(name="🛡️ Moderation Commands", value=mod_commands, inline=False)

        # Ticket Commands
        ticket_commands = """
        `/ticket-setup` - Create interactive ticket panel with buttons
        • Users click button to open support tickets
        • Automatic channel creation with permissions
        • Ticket claiming and closing system
        """
        embed.add_field(name="🎫 Support Ticket System", value=ticket_commands, inline=False)

        # Giveaway Commands
        giveaway_commands = """
        `/giveaway <title> <duration> [winners] [description]` - Quick giveaway
        `/giveaway-setup` - Interactive giveaway creator with all options
        `/giveaway-end <message_id>` - End a giveaway early
        • Duration format: 1h, 30m, 1d, 2h30m
        • Users click 🎉 button to enter
        """
        embed.add_field(name="🎉 Giveaway System", value=giveaway_commands, inline=False)

        # Utility Commands
        utility_commands = """
        `/help` - Show this comprehensive help menu
        `/embed-builder [style]` - Create custom embeds with title & body
        `/ping` - Check bot response time and status
        `/userinfo [member]` - Display detailed user information
        `/serverinfo` - Show complete server statistics
        """
        embed.add_field(name="⚙️ Utility & Admin Tools", value=utility_commands, inline=False)

        embed.add_field(
            name="📋 Important Notes",
            value="• 🛡️ Moderation commands require mod/admin permissions\n• ⚙️ Utility commands available to all members\n• 🎫 Use `/ticket-setup` to create ticket panel\n• 🎉 Giveaways auto-end and select random winners\n• `/embed-builder` has title and body options with templates\n• All embeds use beautiful green color scheme",
            inline=False
        )

        embed.set_footer(text="Use slash commands (/) to interact with the bot")
        embed.set_thumbnail(url=self.bot.user.avatar.url if self.bot.user.avatar else None)

        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="ping", description="Check the bot's latency")
    async def ping(self, interaction: discord.Interaction):
        """Ping command"""
        latency = round(self.bot.latency * 1000)
        embed = create_embed(
            "🏓 Pong!",
            f"Bot latency: **{latency}ms**",
            color=discord.Color.green()
        )
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="userinfo", description="Get information about a user")
    @app_commands.describe(member="The member to get information about")
    async def userinfo(self, interaction: discord.Interaction, member: discord.Member = None):
        """User info command"""
        if member is None:
            member = interaction.user

        embed = create_embed(
            f"👤 User Information - {member.display_name}",
            color=discord.Color.blue()
        )

        embed.add_field(name="Username", value=member.name, inline=True)
        embed.add_field(name="Discriminator", value=f"#{member.discriminator}", inline=True)
        embed.add_field(name="ID", value=member.id, inline=True)

        embed.add_field(name="Account Created", value=discord.utils.format_dt(member.created_at, style='F'), inline=True)
        embed.add_field(name="Joined Server", value=discord.utils.format_dt(member.joined_at, style='F'), inline=True)
        embed.add_field(name="Bot Account", value="Yes" if member.bot else "No", inline=True)

        if member.roles[1:]:  # Exclude @everyone role
            roles = [role.mention for role in reversed(member.roles[1:])]
            embed.add_field(name=f"Roles ({len(roles)})", value=" ".join(roles[:10]), inline=False)

        embed.set_thumbnail(url=member.avatar.url if member.avatar else member.default_avatar.url)
        embed.set_footer(text=f"User ID: {member.id}")

        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="serverinfo", description="Get information about the server")
    async def serverinfo(self, interaction: discord.Interaction):
        """Server info command"""
        guild = interaction.guild
        
        embed = create_embed(
            f"🏠 Server Information - {guild.name}",
            color=discord.Color.blue()
        )

        embed.add_field(name="Server Name", value=guild.name, inline=True)
        embed.add_field(name="Server ID", value=guild.id, inline=True)
        embed.add_field(name="Owner", value=guild.owner.mention if guild.owner else "Unknown", inline=True)

        embed.add_field(name="Created On", value=discord.utils.format_dt(guild.created_at, style='F'), inline=True)
        embed.add_field(name="Member Count", value=guild.member_count, inline=True)
        embed.add_field(name="Boost Level", value=guild.premium_tier, inline=True)

        embed.add_field(name="Text Channels", value=len(guild.text_channels), inline=True)
        embed.add_field(name="Voice Channels", value=len(guild.voice_channels), inline=True)
        embed.add_field(name="Categories", value=len(guild.categories), inline=True)

        embed.add_field(name="Roles", value=len(guild.roles), inline=True)
        embed.add_field(name="Emojis", value=len(guild.emojis), inline=True)
        embed.add_field(name="Boosts", value=guild.premium_subscription_count, inline=True)

        if guild.icon:
            embed.set_thumbnail(url=guild.icon.url)

        embed.set_footer(text=f"Server ID: {guild.id}")

        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="embed-builder", description="Create custom embeds with title, description, colors, and images")
    @app_commands.describe(
        style="Choose embed style: announcement, welcome, rules, info, or custom"
    )
    async def embed_builder(self, interaction: discord.Interaction, style: str = "custom"):
        """Embed builder command with style options"""
        if not await has_mod_permissions(interaction.user, interaction.guild):
            embed = create_error_embed("Permission Denied", "You need moderation permissions to use the embed builder.")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        modal = EmbedBuilderModal()
        
        # Pre-fill based on style
        if style.lower() == "announcement":
            modal.title_input.default = "📢 Server Announcement"
            modal.description_input.default = "Important news for all server members!"
            modal.color_input.default = "orange"
        elif style.lower() == "welcome":
            modal.title_input.default = "👋 Welcome to the Server!"
            modal.description_input.default = "We're glad you're here! Please read the rules and enjoy your stay."
            modal.color_input.default = "green"
        elif style.lower() == "rules":
            modal.title_input.default = "📋 Server Rules"
            modal.description_input.default = "Please follow these rules to keep our community safe and fun for everyone."
            modal.color_input.default = "red"
        elif style.lower() == "info":
            modal.title_input.default = "ℹ️ Information"
            modal.description_input.default = "Here's some important information for the server."
            modal.color_input.default = "blue"
        
        await interaction.response.send_modal(modal)

    @app_commands.command(name="clear", description="Clear messages from the channel")
    @app_commands.describe(amount="Number of messages to delete (1-100)")
    async def clear(self, interaction: discord.Interaction, amount: int):
        """Clear messages command"""
        if not await has_mod_permissions(interaction.user, interaction.guild):
            embed = create_error_embed("Permission Denied", "You need moderation permissions to use this command.")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        if amount < 1 or amount > 100:
            embed = create_error_embed("Invalid Amount", "Please specify a number between 1 and 100.")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        if not interaction.guild.me.guild_permissions.manage_messages:
            embed = create_error_embed("Missing Permissions", "I don't have permission to manage messages.")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        try:
            deleted = await interaction.channel.purge(limit=amount, before=interaction.created_at)
            embed = create_embed(
                "Messages Cleared",
                f"Successfully deleted {len(deleted)} messages.",
                color=0x2ECC71
            )
            await interaction.response.send_message(embed=embed, ephemeral=True)
            
        except discord.Forbidden:
            embed = create_error_embed("Permission Error", "I don't have permission to delete messages in this channel.")
            await interaction.response.send_message(embed=embed, ephemeral=True)
        except Exception as e:
            embed = create_error_embed("Error", f"An error occurred: {str(e)}")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            logger.error(f"Clear command error: {e}")

    @app_commands.command(name="testlog", description="Test the logging system")
    async def testlog(self, interaction: discord.Interaction):
        """Test logging command"""
        if not await has_mod_permissions(interaction.user, interaction.guild):
            embed = create_error_embed("Permission Denied", "You need moderation permissions to use this command.")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        # Create a test log entry
        embed = create_embed(
            "🧪 Test Log Entry",
            f"**Test by:** {interaction.user.mention}\n**Time:** <t:{int(discord.utils.utcnow().timestamp())}:F>\n**Channel:** {interaction.channel.mention}",
            color=0x9B59B6
        )
        
        # Try to send to log channel
        try:
            with open('config.json', 'r') as f:
                config = json.load(f)
            
            log_channel_id = config.get('log_channel_id')
            if log_channel_id:
                log_channel = interaction.guild.get_channel(log_channel_id)
                if log_channel:
                    await log_channel.send(embed=embed)
                    await interaction.response.send_message("✅ Test log sent successfully!", ephemeral=True)
                else:
                    await interaction.response.send_message(f"❌ Could not find log channel with ID {log_channel_id}", ephemeral=True)
            else:
                await interaction.response.send_message("❌ No log channel configured", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"❌ Error: {str(e)}", ephemeral=True)

async def setup(bot):
    await bot.add_cog(Utilities(bot))
