import discord
from discord.ext import commands
from discord import app_commands
import json
import logging
from datetime import datetime, timedelta
from utils.embeds import create_embed, create_error_embed
from utils.permissions import has_mod_permissions, has_admin_permissions, log_moderation_action

logger = logging.getLogger(__name__)

class Moderation(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        
    async def get_config(self):
        """Get bot configuration"""
        try:
            with open('config.json', 'r') as f:
                return json.load(f)
        except:
            return {}

    async def get_log_channel(self, guild):
        """Get the moderation log channel"""
        config = await self.get_config()
        channel_name = config.get('log_channel_name', 'mod-logs')
        return discord.utils.get(guild.channels, name=channel_name)

    @app_commands.command(name="kick", description="Kick a member from the server")
    @app_commands.describe(
        member="The member to kick",
        reason="Reason for the kick"
    )
    async def kick(self, interaction: discord.Interaction, member: discord.Member, reason: str = "No reason provided"):
        """Kick command"""
        if not await has_mod_permissions(interaction.user, interaction.guild):
            embed = create_error_embed("Permission Denied", "You don't have permission to use this command.")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        if member.top_role >= interaction.user.top_role and interaction.user != interaction.guild.owner:
            embed = create_error_embed("Permission Denied", "You cannot kick someone with a higher or equal role.")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        if not interaction.guild.me.guild_permissions.kick_members:
            embed = create_error_embed("Missing Permissions", "I don't have permission to kick members.")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        try:
            # Send DM to user before kicking
            try:
                dm_embed = create_embed(
                    "You have been kicked",
                    f"**Server:** {interaction.guild.name}\n**Reason:** {reason}\n**Moderator:** {interaction.user.mention}",
                    color=discord.Color.orange()
                )
                await member.send(embed=dm_embed)
            except:
                pass  # User has DMs disabled

            # Kick the member
            await member.kick(reason=f"{reason} | Kicked by {interaction.user}")
            
            # Log the action
            await log_moderation_action(
                interaction.guild, "kick", interaction.user, member, reason
            )

            # Send confirmation
            embed = create_embed(
                "Member Kicked",
                f"**User:** {member.mention} ({member.id})\n**Reason:** {reason}\n**Moderator:** {interaction.user.mention}",
                color=discord.Color.orange()
            )
            await interaction.response.send_message(embed=embed)



        except discord.Forbidden:
            embed = create_error_embed("Permission Error", "I don't have permission to kick this user.")
            await interaction.response.send_message(embed=embed, ephemeral=True)
        except Exception as e:
            embed = create_error_embed("Error", f"An error occurred: {str(e)}")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            logger.error(f"Kick error: {e}")

    @app_commands.command(name="ban", description="Ban a member from the server")
    @app_commands.describe(
        member="The member to ban",
        reason="Reason for the ban",
        delete_messages="Delete messages from the last X days (0-7)"
    )
    async def ban(self, interaction: discord.Interaction, member: discord.Member, reason: str = "No reason provided", delete_messages: int = 0):
        """Ban command"""
        if not await has_mod_permissions(interaction.user, interaction.guild):
            embed = create_error_embed("Permission Denied", "You don't have permission to use this command.")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        if member.top_role >= interaction.user.top_role and interaction.user != interaction.guild.owner:
            embed = create_error_embed("Permission Denied", "You cannot ban someone with a higher or equal role.")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        if not interaction.guild.me.guild_permissions.ban_members:
            embed = create_error_embed("Missing Permissions", "I don't have permission to ban members.")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        if delete_messages < 0 or delete_messages > 7:
            embed = create_error_embed("Invalid Parameter", "Delete messages must be between 0 and 7 days.")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        try:
            # Send DM to user before banning
            try:
                dm_embed = create_embed(
                    "You have been banned",
                    f"**Server:** {interaction.guild.name}\n**Reason:** {reason}\n**Moderator:** {interaction.user.mention}",
                    color=discord.Color.red()
                )
                await member.send(embed=dm_embed)
            except:
                pass  # User has DMs disabled

            # Ban the member
            await member.ban(reason=f"{reason} | Banned by {interaction.user}", delete_message_days=delete_messages)
            
            # Log the action
            await log_moderation_action(
                interaction.guild, "ban", interaction.user, member, reason
            )

            # Send confirmation
            embed = create_embed(
                "Member Banned",
                f"**User:** {member.mention} ({member.id})\n**Reason:** {reason}\n**Moderator:** {interaction.user.mention}",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=embed)



        except discord.Forbidden:
            embed = create_error_embed("Permission Error", "I don't have permission to ban this user.")
            await interaction.response.send_message(embed=embed, ephemeral=True)
        except Exception as e:
            embed = create_error_embed("Error", f"An error occurred: {str(e)}")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            logger.error(f"Ban error: {e}")

    @app_commands.command(name="mute", description="Timeout a member")
    @app_commands.describe(
        member="The member to mute",
        duration="Duration in minutes",
        reason="Reason for the mute"
    )
    async def mute(self, interaction: discord.Interaction, member: discord.Member, duration: int, reason: str = "No reason provided"):
        """Mute/timeout command"""
        if not await has_mod_permissions(interaction.user, interaction.guild):
            embed = create_error_embed("Permission Denied", "You don't have permission to use this command.")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        if member.top_role >= interaction.user.top_role and interaction.user != interaction.guild.owner:
            embed = create_error_embed("Permission Denied", "You cannot mute someone with a higher or equal role.")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        if not interaction.guild.me.guild_permissions.moderate_members:
            embed = create_error_embed("Missing Permissions", "I don't have permission to timeout members.")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        if duration <= 0 or duration > 40320:  # Discord's max timeout is 28 days
            embed = create_error_embed("Invalid Duration", "Duration must be between 1 minute and 28 days (40320 minutes).")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        try:
            # Calculate timeout duration using UTC aware datetime
            timeout_until = discord.utils.utcnow() + timedelta(minutes=duration)

            # Send DM to user before muting
            try:
                dm_embed = create_embed(
                    "You have been muted",
                    f"**Server:** {interaction.guild.name}\n**Duration:** {duration} minutes\n**Reason:** {reason}\n**Moderator:** {interaction.user.mention}",
                    color=discord.Color.yellow()
                )
                await member.send(embed=dm_embed)
            except:
                pass  # User has DMs disabled

            # Timeout the member
            await member.timeout(timeout_until, reason=f"{reason} | Muted by {interaction.user}")
            
            # Log the action
            await log_moderation_action(
                interaction.guild, "mute", interaction.user, member, reason, f"{duration} minutes"
            )

            # Send confirmation
            embed = create_embed(
                "Member Muted",
                f"**User:** {member.mention} ({member.id})\n**Duration:** {duration} minutes\n**Reason:** {reason}\n**Moderator:** {interaction.user.mention}",
                color=discord.Color.yellow()
            )
            await interaction.response.send_message(embed=embed)



        except discord.Forbidden:
            embed = create_error_embed("Permission Error", "I don't have permission to timeout this user.")
            await interaction.response.send_message(embed=embed, ephemeral=True)
        except Exception as e:
            embed = create_error_embed("Error", f"An error occurred: {str(e)}")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            logger.error(f"Mute error: {e}")



    @app_commands.command(name="unmute", description="Remove timeout from a member")
    @app_commands.describe(
        member="The member to unmute",
        reason="Reason for the unmute"
    )
    async def unmute(self, interaction: discord.Interaction, member: discord.Member, reason: str = "No reason provided"):
        """Unmute command"""
        if not await has_mod_permissions(interaction.user, interaction.guild):
            embed = create_error_embed("Permission Denied", "You don't have permission to use this command.")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        if not interaction.guild.me.guild_permissions.moderate_members:
            embed = create_error_embed("Missing Permissions", "I don't have permission to remove timeouts.")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        try:
            if member.timed_out_until is None:
                embed = create_error_embed("Not Muted", "This member is not currently muted.")
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return

            # Remove timeout
            await member.timeout(None, reason=f"{reason} | Unmuted by {interaction.user}")
            
            # Log the action
            await log_moderation_action(
                interaction.guild, "unmute", interaction.user, member, reason
            )

            # Send confirmation
            embed = create_embed(
                "Member Unmuted",
                f"**User:** {member.mention} ({member.id})\n**Reason:** {reason}\n**Moderator:** {interaction.user.mention}",
                color=discord.Color.green()
            )
            await interaction.response.send_message(embed=embed)

        except discord.Forbidden:
            embed = create_error_embed("Permission Error", "I don't have permission to remove timeout from this user.")
            await interaction.response.send_message(embed=embed, ephemeral=True)
        except Exception as e:
            embed = create_error_embed("Error", f"An error occurred: {str(e)}")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            logger.error(f"Unmute error: {e}")

async def setup(bot):
    await bot.add_cog(Moderation(bot))
