import discord
from discord.ext import commands
import json
import logging
from utils.embeds import create_embed
from utils.permissions import log_moderation_action

logger = logging.getLogger(__name__)

class AutoRoles(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        
    async def get_config(self):
        """Get bot configuration"""
        try:
            with open('config.json', 'r') as f:
                return json.load(f)
        except:
            return {}

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        """Give auto-roles to new members"""
        try:
            config = await self.get_config()
            auto_role_ids = config.get('auto_roles', [])
            
            if not auto_role_ids:
                logger.info("No auto-roles configured")
                return
            
            # Get roles that exist in the guild
            roles_to_add = []
            for role_id in auto_role_ids:
                role = member.guild.get_role(role_id)
                if role:
                    roles_to_add.append(role)
                else:
                    logger.warning(f"Auto-role {role_id} not found in guild {member.guild.name}")
            
            if not roles_to_add:
                logger.warning("No valid auto-roles found")
                return
            
            # Add roles to the member
            await member.add_roles(*roles_to_add, reason="Auto-role assignment on join")
            
            role_names = [role.name for role in roles_to_add]
            logger.info(f"Added auto-roles {role_names} to {member} in {member.guild.name}")
            
            # Note: Member join logging is handled by the logging cog
            
        except discord.Forbidden:
            logger.error(f"Missing permissions to add roles to {member} in {member.guild.name}")
        except Exception as e:
            logger.error(f"Error adding auto-roles to {member}: {e}")



async def setup(bot):
    await bot.add_cog(AutoRoles(bot))