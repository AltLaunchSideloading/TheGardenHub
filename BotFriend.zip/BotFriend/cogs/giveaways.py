import discord
from discord.ext import commands, tasks
from discord import app_commands
import json
import logging
import random
import asyncio
from datetime import datetime, timedelta
from utils.embeds import create_embed, create_error_embed, create_success_embed
from utils.permissions import has_mod_permissions
from database import db

logger = logging.getLogger(__name__)

class GiveawayView(discord.ui.View):
    def __init__(self, giveaway_id):
        super().__init__(timeout=None)
        self.giveaway_id = giveaway_id

    @discord.ui.button(label="🎉 Enter Giveaway", style=discord.ButtonStyle.primary, custom_id="enter_giveaway")
    async def enter_giveaway(self, interaction: discord.Interaction, button: discord.ui.Button):
        """Handle giveaway entry"""
        cog = interaction.client.get_cog('Giveaways')
        if cog:
            await cog.handle_giveaway_entry(interaction, self.giveaway_id)

class GiveawayModal(discord.ui.Modal, title="Create Giveaway"):
    def __init__(self):
        super().__init__()

    title_input = discord.ui.TextInput(
        label="🎁 Giveaway Title",
        placeholder="Discord Nitro Giveaway, $50 Steam Gift Card, etc.",
        max_length=100,
        required=True
    )

    description_input = discord.ui.TextInput(
        label="📝 Description",
        placeholder="Win a month of Discord Nitro! Click the button below to enter.",
        style=discord.TextStyle.paragraph,
        max_length=1000,
        required=False
    )

    duration_input = discord.ui.TextInput(
        label="⏰ Duration",
        placeholder="1h, 30m, 1d, 2h30m (hours/minutes/days)",
        max_length=20,
        required=True
    )

    winners_input = discord.ui.TextInput(
        label="🏆 Number of Winners",
        placeholder="1",
        max_length=2,
        required=False,
        default="1"
    )

    requirements_input = discord.ui.TextInput(
        label="📋 Requirements (Optional)",
        placeholder="Must be level 5+, Must have X role, etc.",
        max_length=200,
        required=False
    )

    async def on_submit(self, interaction: discord.Interaction):
        """Handle giveaway creation modal submission"""
        cog = interaction.client.get_cog('Giveaways')
        if cog:
            await cog.create_giveaway_from_modal(
                interaction,
                self.title_input.value,
                self.description_input.value,
                self.duration_input.value,
                self.winners_input.value,
                self.requirements_input.value
            )

class Giveaways(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.check_giveaways.start()
        
    async def cog_load(self):
        """Initialize giveaway tables"""
        await self.init_giveaway_tables()
    
    async def init_giveaway_tables(self):
        """Create giveaway tables"""
        await db.execute('''
            CREATE TABLE IF NOT EXISTS giveaways (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id INTEGER NOT NULL,
                channel_id INTEGER NOT NULL,
                message_id INTEGER NOT NULL,
                title TEXT NOT NULL,
                description TEXT,
                creator_id INTEGER NOT NULL,
                end_time TIMESTAMP NOT NULL,
                winners_count INTEGER DEFAULT 1,
                requirements TEXT,
                ended BOOLEAN DEFAULT FALSE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        await db.execute('''
            CREATE TABLE IF NOT EXISTS giveaway_entries (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                giveaway_id INTEGER NOT NULL,
                user_id INTEGER NOT NULL,
                entered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (giveaway_id) REFERENCES giveaways (id),
                UNIQUE(giveaway_id, user_id)
            )
        ''')

    def parse_duration(self, duration_str):
        """Parse duration string like '1h30m', '2d', '45m' into timedelta"""
        duration_str = duration_str.lower().strip()
        total_seconds = 0
        
        # Extract numbers and units
        import re
        patterns = [
            (r'(\d+)d', 86400),  # days
            (r'(\d+)h', 3600),   # hours
            (r'(\d+)m', 60),     # minutes
            (r'(\d+)s', 1),      # seconds
        ]
        
        for pattern, multiplier in patterns:
            matches = re.findall(pattern, duration_str)
            for match in matches:
                total_seconds += int(match) * multiplier
        
        if total_seconds == 0:
            raise ValueError("Invalid duration format")
        
        return timedelta(seconds=total_seconds)

    @app_commands.command(name="giveaway", description="Create a new giveaway with custom prize and duration")
    @app_commands.describe(
        title="The giveaway prize/title",
        duration="Duration (e.g., 1h, 30m, 1d, 2h30m)",
        winners="Number of winners (default: 1)",
        description="Additional description for the giveaway"
    )
    async def create_giveaway(self, interaction: discord.Interaction, title: str, duration: str, winners: int = 1, description: str = None):
        """Create a giveaway command"""
        if not await has_mod_permissions(interaction.user, interaction.guild):
            embed = create_error_embed("Permission Denied", "You need moderation permissions to create giveaways.")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        try:
            # Parse duration
            duration_delta = self.parse_duration(duration)
            end_time = datetime.now() + duration_delta
            
            if winners < 1 or winners > 20:
                embed = create_error_embed("Invalid Winners", "Number of winners must be between 1 and 20.")
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return
            
            # Create giveaway embed
            giveaway_embed = create_embed(
                f"🎉 {title}",
                f"{description or 'Click the button below to enter!'}\n\n"
                f"**⏰ Ends:** {discord.utils.format_dt(end_time, style='R')}\n"
                f"**🏆 Winners:** {winners}\n"
                f"**👤 Host:** {interaction.user.mention}\n"
                f"**📊 Entries:** 0",
                color=discord.Color.gold()
            )
            giveaway_embed.set_footer(text="Good luck to everyone! 🍀")
            
            # Send giveaway message
            view = GiveawayView(None)  # Will update with ID after database insert
            await interaction.response.send_message(embed=giveaway_embed, view=view)
            message = await interaction.original_response()
            
            # Store in database
            cursor = await db.execute(
                'INSERT INTO giveaways (guild_id, channel_id, message_id, title, description, creator_id, end_time, winners_count) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                (interaction.guild.id, interaction.channel.id, message.id, title, description, interaction.user.id, end_time, winners)
            )
            giveaway_id = cursor.lastrowid
            
            # Update the view with the correct ID
            view.giveaway_id = giveaway_id
            await message.edit(embed=giveaway_embed, view=view)
            
        except ValueError as e:
            embed = create_error_embed("Invalid Duration", "Please use format like: 1h, 30m, 1d, 2h30m")
            await interaction.response.send_message(embed=embed, ephemeral=True)
        except Exception as e:
            embed = create_error_embed("Error", f"Failed to create giveaway: {str(e)}")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            logger.error(f"Giveaway creation error: {e}")

    @app_commands.command(name="giveaway-setup", description="Interactive giveaway creator with detailed options")
    async def giveaway_setup(self, interaction: discord.Interaction):
        """Interactive giveaway setup"""
        if not await has_mod_permissions(interaction.user, interaction.guild):
            embed = create_error_embed("Permission Denied", "You need moderation permissions to create giveaways.")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        modal = GiveawayModal()
        await interaction.response.send_modal(modal)

    async def create_giveaway_from_modal(self, interaction, title, description, duration_str, winners_str, requirements):
        """Create giveaway from modal input"""
        try:
            # Parse inputs
            duration_delta = self.parse_duration(duration_str)
            end_time = datetime.now() + duration_delta
            
            try:
                winners = int(winners_str) if winners_str else 1
            except ValueError:
                winners = 1
            
            if winners < 1 or winners > 20:
                embed = create_error_embed("Invalid Winners", "Number of winners must be between 1 and 20.")
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return
            
            # Create detailed giveaway embed
            embed_description = f"{description or 'Enter this amazing giveaway!'}\n\n"
            embed_description += f"**⏰ Ends:** {discord.utils.format_dt(end_time, style='R')}\n"
            embed_description += f"**🏆 Winners:** {winners}\n"
            embed_description += f"**👤 Host:** {interaction.user.mention}\n"
            
            if requirements:
                embed_description += f"**📋 Requirements:** {requirements}\n"
            
            embed_description += f"**📊 Entries:** 0"
            
            giveaway_embed = create_embed(
                f"🎉 {title}",
                embed_description,
                color=discord.Color.gold()
            )
            giveaway_embed.set_footer(text="Click the button below to enter! Good luck! 🍀")
            
            # Send giveaway
            view = GiveawayView(None)
            await interaction.response.send_message(embed=giveaway_embed, view=view)
            message = await interaction.original_response()
            
            # Store in database
            cursor = await db.execute(
                'INSERT INTO giveaways (guild_id, channel_id, message_id, title, description, creator_id, end_time, winners_count, requirements) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
                (interaction.guild.id, interaction.channel.id, message.id, title, description, interaction.user.id, end_time, winners, requirements)
            )
            giveaway_id = cursor.lastrowid
            
            # Update view
            view.giveaway_id = giveaway_id
            await message.edit(embed=giveaway_embed, view=view)
            
        except ValueError:
            embed = create_error_embed("Invalid Duration", "Please use format like: 1h, 30m, 1d, 2h30m")
            await interaction.response.send_message(embed=embed, ephemeral=True)
        except Exception as e:
            embed = create_error_embed("Error", f"Failed to create giveaway: {str(e)}")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            logger.error(f"Giveaway modal error: {e}")

    async def handle_giveaway_entry(self, interaction, giveaway_id):
        """Handle user entering a giveaway"""
        try:
            # Check if giveaway exists and hasn't ended
            giveaway = await db.fetchone('SELECT * FROM giveaways WHERE id = ? AND ended = FALSE', (giveaway_id,))
            if not giveaway:
                embed = create_error_embed("Giveaway Not Found", "This giveaway has ended or doesn't exist.")
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return
            
            # Check if user already entered
            existing_entry = await db.fetchone('SELECT * FROM giveaway_entries WHERE giveaway_id = ? AND user_id = ?', (giveaway_id, interaction.user.id))
            if existing_entry:
                embed = create_error_embed("Already Entered", "You have already entered this giveaway!")
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return
            
            # Add entry
            await db.execute('INSERT INTO giveaway_entries (giveaway_id, user_id) VALUES (?, ?)', (giveaway_id, interaction.user.id))
            
            # Update entry count in embed
            entry_count = await db.fetchone('SELECT COUNT(*) as count FROM giveaway_entries WHERE giveaway_id = ?', (giveaway_id,))
            count = entry_count['count']
            
            # Get message and update embed
            channel = self.bot.get_channel(giveaway['channel_id'])
            if channel:
                try:
                    message = await channel.fetch_message(giveaway['message_id'])
                    embed = message.embeds[0]
                    
                    # Update entry count in description
                    description_lines = embed.description.split('\n')
                    for i, line in enumerate(description_lines):
                        if line.startswith('**📊 Entries:**'):
                            description_lines[i] = f"**📊 Entries:** {count}"
                            break
                    
                    embed.description = '\n'.join(description_lines)
                    await message.edit(embed=embed, view=message.components[0] if message.components else None)
                except:
                    pass  # Message might be deleted
            
            # Confirm entry
            embed = create_success_embed("Entered!", f"You've successfully entered the giveaway: **{giveaway['title']}**")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            
        except Exception as e:
            embed = create_error_embed("Error", "Failed to enter giveaway.")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            logger.error(f"Giveaway entry error: {e}")

    @app_commands.command(name="giveaway-end", description="Manually end a giveaway early")
    @app_commands.describe(message_id="The message ID of the giveaway to end")
    async def end_giveaway(self, interaction: discord.Interaction, message_id: str):
        """Manually end a giveaway"""
        if not await has_mod_permissions(interaction.user, interaction.guild):
            embed = create_error_embed("Permission Denied", "You need moderation permissions to end giveaways.")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            return

        try:
            msg_id = int(message_id)
            giveaway = await db.fetchone('SELECT * FROM giveaways WHERE message_id = ? AND guild_id = ? AND ended = FALSE', (msg_id, interaction.guild.id))
            
            if not giveaway:
                embed = create_error_embed("Giveaway Not Found", "No active giveaway found with that message ID.")
                await interaction.response.send_message(embed=embed, ephemeral=True)
                return
            
            await self.end_giveaway_process(giveaway['id'])
            embed = create_success_embed("Giveaway Ended", f"Successfully ended the giveaway: **{giveaway['title']}**")
            await interaction.response.send_message(embed=embed, ephemeral=True)
            
        except ValueError:
            embed = create_error_embed("Invalid Message ID", "Please provide a valid message ID.")
            await interaction.response.send_message(embed=embed, ephemeral=True)
        except Exception as e:
            embed = create_error_embed("Error", f"Failed to end giveaway: {str(e)}")
            await interaction.response.send_message(embed=embed, ephemeral=True)

    async def end_giveaway_process(self, giveaway_id):
        """Process ending a giveaway"""
        try:
            # Get giveaway data
            giveaway = await db.fetchone('SELECT * FROM giveaways WHERE id = ?', (giveaway_id,))
            if not giveaway:
                return
            
            # Get all entries
            entries = await db.fetchall('SELECT user_id FROM giveaway_entries WHERE giveaway_id = ?', (giveaway_id,))
            
            # Select winners
            winners = []
            if entries:
                entry_users = [entry['user_id'] for entry in entries]
                winners_count = min(giveaway['winners_count'], len(entry_users))
                winners = random.sample(entry_users, winners_count)
            
            # Update giveaway as ended
            await db.execute('UPDATE giveaways SET ended = TRUE WHERE id = ?', (giveaway_id,))
            
            # Get channel and message
            channel = self.bot.get_channel(giveaway['channel_id'])
            if not channel:
                return
            
            try:
                message = await channel.fetch_message(giveaway['message_id'])
                
                # Create ended embed
                if winners:
                    winner_mentions = []
                    for winner_id in winners:
                        user = self.bot.get_user(winner_id)
                        if user:
                            winner_mentions.append(user.mention)
                        else:
                            winner_mentions.append(f"<@{winner_id}>")
                    
                    embed = create_embed(
                        f"🎉 {giveaway['title']} - ENDED",
                        f"**🏆 Winners:** {', '.join(winner_mentions)}\n"
                        f"**📊 Total Entries:** {len(entries)}\n"
                        f"**👤 Host:** <@{giveaway['creator_id']}>",
                        color=discord.Color.gold()
                    )
                    embed.set_footer(text="Congratulations to the winners! 🎉")
                    
                    # Send winner announcement
                    winner_embed = create_embed(
                        f"🎉 Giveaway Winner{'s' if len(winners) > 1 else ''}!",
                        f"Congratulations {', '.join(winner_mentions)}!\n\n"
                        f"You won: **{giveaway['title']}**\n\n"
                        f"Please contact <@{giveaway['creator_id']}> to claim your prize!",
                        color=discord.Color.gold()
                    )
                    await channel.send(embed=winner_embed)
                    
                else:
                    embed = create_embed(
                        f"🎉 {giveaway['title']} - ENDED",
                        f"**🏆 Winners:** No entries\n"
                        f"**📊 Total Entries:** 0\n"
                        f"**👤 Host:** <@{giveaway['creator_id']}>",
                        color=discord.Color.red()
                    )
                    embed.set_footer(text="No one entered this giveaway.")
                
                # Update original message
                await message.edit(embed=embed, view=None)
                
            except discord.NotFound:
                pass  # Message was deleted
                
        except Exception as e:
            logger.error(f"Error ending giveaway {giveaway_id}: {e}")

    @tasks.loop(minutes=1)
    async def check_giveaways(self):
        """Check for expired giveaways"""
        try:
            now = datetime.now()
            expired_giveaways = await db.fetchall('SELECT * FROM giveaways WHERE end_time <= ? AND ended = FALSE', (now,))
            
            for giveaway in expired_giveaways:
                await self.end_giveaway_process(giveaway['id'])
                
        except Exception as e:
            logger.error(f"Error checking giveaways: {e}")

    @check_giveaways.before_loop
    async def before_check_giveaways(self):
        await self.bot.wait_until_ready()

    @commands.Cog.listener()
    async def on_ready(self):
        """Add persistent views when bot starts"""
        # Add view for all active giveaways
        active_giveaways = await db.fetchall('SELECT id FROM giveaways WHERE ended = FALSE')
        for giveaway in active_giveaways:
            self.bot.add_view(GiveawayView(giveaway['id']))

async def setup(bot):
    await bot.add_cog(Giveaways(bot))