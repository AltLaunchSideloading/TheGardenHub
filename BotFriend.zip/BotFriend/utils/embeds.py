import discord
from datetime import datetime

def create_embed(title=None, description=None, color=None, thumbnail=None, image=None, footer=None, author=None):
    """
    Create a standardized embed with optional parameters
    
    Args:
        title (str): Embed title
        description (str): Embed description
        color (discord.Color): Embed color
        thumbnail (str): Thumbnail URL
        image (str): Image URL
        footer (str): Footer text
        author (dict): Author info with keys: name, icon_url, url
    
    Returns:
        discord.Embed: The created embed
    """
    if color is None:
        color = discord.Color.green()
    
    embed = discord.Embed(
        title=title,
        description=description,
        color=color,
        timestamp=datetime.utcnow()
    )
    
    if thumbnail:
        embed.set_thumbnail(url=thumbnail)
    
    if image:
        embed.set_image(url=image)
    
    if footer:
        embed.set_footer(text=footer)
    
    if author:
        embed.set_author(
            name=author.get('name', ''),
            icon_url=author.get('icon_url', ''),
            url=author.get('url', '')
        )
    
    return embed

def create_success_embed(title, description=None):
    """Create a success embed with green color"""
    return create_embed(
        title=f"✅ {title}",
        description=description,
        color=discord.Color.green()
    )

def create_error_embed(title, description=None):
    """Create an error embed with red color"""
    return create_embed(
        title=f"❌ {title}",
        description=description,
        color=discord.Color.red()
    )

def create_warning_embed(title, description=None):
    """Create a warning embed with yellow color"""
    return create_embed(
        title=f"⚠️ {title}",
        description=description,
        color=discord.Color.yellow()
    )

def create_info_embed(title, description=None):
    """Create an info embed with green color"""
    return create_embed(
        title=f"ℹ️ {title}",
        description=description,
        color=discord.Color.green()
    )

def create_moderation_embed(action, user, moderator, reason=None, duration=None):
    """
    Create a standardized moderation embed
    
    Args:
        action (str): The moderation action (kick, ban, mute, etc.)
        user (discord.Member): The user being moderated
        moderator (discord.Member): The moderator performing the action
        reason (str): Reason for the action
        duration (str): Duration for temporary actions
    
    Returns:
        discord.Embed: The moderation embed
    """
    action_colors = {
        'kick': discord.Color.orange(),
        'ban': discord.Color.red(),
        'mute': discord.Color.yellow(),
        'unmute': discord.Color.green(),
        'warn': discord.Color.yellow(),
        'timeout': discord.Color.yellow()
    }
    
    action_emojis = {
        'kick': '🦶',
        'ban': '🔨',
        'mute': '🔇',
        'unmute': '🔊',
        'warn': '⚠️',
        'timeout': '⏰'
    }
    
    color = action_colors.get(action.lower(), discord.Color.default())
    emoji = action_emojis.get(action.lower(), '🔨')
    
    embed = create_embed(
        title=f"{emoji} {action.capitalize()} Action",
        color=color
    )
    
    embed.add_field(name="User", value=f"{user.mention} ({user.id})", inline=True)
    embed.add_field(name="Moderator", value=moderator.mention, inline=True)
    
    if duration:
        embed.add_field(name="Duration", value=duration, inline=True)
    
    if reason:
        embed.add_field(name="Reason", value=reason, inline=False)
    else:
        embed.add_field(name="Reason", value="No reason provided", inline=False)
    
    embed.set_footer(text=f"User ID: {user.id}")
    
    return embed

def create_ticket_embed(ticket_id, user, subject=None, description=None):
    """
    Create a ticket embed
    
    Args:
        ticket_id (int): Ticket ID
        user (discord.Member): User who created the ticket
        subject (str): Ticket subject
        description (str): Ticket description
    
    Returns:
        discord.Embed: The ticket embed
    """
    embed = create_embed(
        title=f"🎫 Support Ticket #{ticket_id:04d}",
        color=discord.Color.green()
    )
    
    embed.add_field(name="Created by", value=user.mention, inline=True)
    embed.add_field(name="User ID", value=user.id, inline=True)
    embed.add_field(name="Created", value=discord.utils.format_dt(datetime.utcnow(), style='R'), inline=True)
    
    if subject:
        embed.add_field(name="Subject", value=subject, inline=False)
    
    if description:
        embed.add_field(name="Description", value=description, inline=False)
    
    embed.set_thumbnail(url=user.avatar.url if user.avatar else user.default_avatar.url)
    embed.set_footer(text=f"Ticket ID: {ticket_id}")
    
    return embed

def create_help_embed(commands_data):
    """
    Create a help embed with command information
    
    Args:
        commands_data (dict): Dictionary with categories as keys and command lists as values
    
    Returns:
        discord.Embed: The help embed
    """
    embed = create_embed(
        title="🤖 Bot Commands",
        description="Here are all the available commands:",
        color=discord.Color.blue()
    )
    
    for category, commands in commands_data.items():
        command_list = []
        for cmd in commands:
            command_list.append(f"`{cmd['name']}` - {cmd['description']}")
        
        embed.add_field(
            name=category,
            value="\n".join(command_list),
            inline=False
        )
    
    embed.set_footer(text="Use slash commands (/) to interact with the bot")
    
    return embed
