import discord
import json
import logging

logger = logging.getLogger(__name__)

async def get_config():
    """Get bot configuration"""
    try:
        with open('config.json', 'r') as f:
            return json.load(f)
    except:
        return {}

async def has_mod_permissions(user: discord.Member, guild: discord.Guild) -> bool:
    """
    Check if a user has moderation permissions
    
    Args:
        user (discord.Member): The user to check
        guild (discord.Guild): The guild to check in
    
    Returns:
        bool: True if user has mod permissions, False otherwise
    """
    # Guild owner always has permissions
    if user == guild.owner:
        return True
    
    # Check for administrator permission
    if user.guild_permissions.administrator:
        return True
    
    # Check for configured moderator role by ID first
    config = await get_config()
    mod_role_id = config.get('mod_role_id')
    
    if mod_role_id:
        mod_role = guild.get_role(mod_role_id)
        if mod_role and mod_role in user.roles:
            return True
    
    # Fallback to role name check
    mod_role_name = config.get('mod_role_name', 'Moderator')
    mod_role = discord.utils.get(guild.roles, name=mod_role_name)
    
    if mod_role and mod_role in user.roles:
        return True
    
    return False

async def has_admin_permissions(user: discord.Member, guild: discord.Guild) -> bool:
    """
    Check if a user has administrator permissions
    
    Args:
        user (discord.Member): The user to check
        guild (discord.Guild): The guild to check in
    
    Returns:
        bool: True if user has admin permissions, False otherwise
    """
    # Guild owner always has permissions
    if user == guild.owner:
        return True
    
    # Check for administrator permission
    if user.guild_permissions.administrator:
        return True
    
    # Check for configured admin role by ID first
    config = await get_config()
    admin_role_id = config.get('admin_role_id')
    
    if admin_role_id:
        admin_role = guild.get_role(admin_role_id)
        if admin_role and admin_role in user.roles:
            return True
    
    # Fallback to role name check
    admin_role_name = config.get('admin_role_name', 'Admin')
    admin_role = discord.utils.get(guild.roles, name=admin_role_name)
    
    if admin_role and admin_role in user.roles:
        return True
    
    return False

async def has_ticket_permissions(user: discord.Member, guild: discord.Guild) -> bool:
    """
    Check if a user can manage tickets
    
    Args:
        user (discord.Member): The user to check
        guild (discord.Guild): The guild to check in
    
    Returns:
        bool: True if user can manage tickets, False otherwise
    """
    # Admin and mod permissions allow ticket management
    if await has_admin_permissions(user, guild) or await has_mod_permissions(user, guild):
        return True
    
    # Check for manage channels permission
    if user.guild_permissions.manage_channels:
        return True
    
    return False

def check_hierarchy(moderator: discord.Member, target: discord.Member, guild: discord.Guild) -> bool:
    """
    Check if moderator can perform actions on target based on role hierarchy
    
    Args:
        moderator (discord.Member): The moderator performing the action
        target (discord.Member): The target of the action
        guild (discord.Guild): The guild where the action is taking place
    
    Returns:
        bool: True if action is allowed, False otherwise
    """
    # Guild owner can do anything to anyone
    if moderator == guild.owner:
        return True
    
    # Can't moderate the guild owner
    if target == guild.owner:
        return False
    
    # Can't moderate someone with higher or equal role
    if target.top_role >= moderator.top_role:
        return False
    
    # Can't moderate someone if the bot can't
    if target.top_role >= guild.me.top_role:
        return False
    
    return True

async def can_moderate_user(moderator: discord.Member, target: discord.Member, guild: discord.Guild, action: str) -> tuple[bool, str]:
    """
    Check if a moderator can perform a specific action on a target user
    
    Args:
        moderator (discord.Member): The moderator performing the action
        target (discord.Member): The target of the action
        guild (discord.Guild): The guild where the action is taking place
        action (str): The action being performed (kick, ban, mute, etc.)
    
    Returns:
        tuple[bool, str]: (can_perform_action, reason_if_not)
    """
    # Check if moderator has required permissions
    if not await has_mod_permissions(moderator, guild):
        return False, "You don't have moderation permissions."
    
    # Check role hierarchy
    if not check_hierarchy(moderator, target, guild):
        return False, "You cannot moderate someone with a higher or equal role."
    
    # Check bot permissions for specific actions
    action_permissions = {
        'kick': 'kick_members',
        'ban': 'ban_members',
        'mute': 'moderate_members',
        'timeout': 'moderate_members'
    }
    
    required_permission = action_permissions.get(action.lower())
    if required_permission:
        if not getattr(guild.me.guild_permissions, required_permission, False):
            return False, f"I don't have permission to {action} members."
    
    return True, "Action allowed"

async def get_permission_level(user: discord.Member, guild: discord.Guild) -> str:
    """
    Get the permission level of a user
    
    Args:
        user (discord.Member): The user to check
        guild (discord.Guild): The guild to check in
    
    Returns:
        str: The permission level (owner, admin, moderator, member)
    """
    if user == guild.owner:
        return "owner"
    
    if await has_admin_permissions(user, guild):
        return "admin"
    
    if await has_mod_permissions(user, guild):
        return "moderator"
    
    return "member"

def format_permissions(permissions: discord.Permissions) -> list[str]:
    """
    Format permissions into a readable list
    
    Args:
        permissions (discord.Permissions): The permissions to format
    
    Returns:
        list[str]: List of permission names
    """
    permission_names = []
    
    for perm, value in permissions:
        if value:
            # Convert permission name to readable format
            readable_name = perm.replace('_', ' ').title()
            permission_names.append(readable_name)
    
    return permission_names

async def log_moderation_action(guild: discord.Guild, action: str, moderator: discord.Member, target: discord.Member, reason: str = None, duration: str = None):
    """
    Log a moderation action to the configured log channel
    
    Args:
        guild (discord.Guild): The guild where the action occurred
        action (str): The action performed (kick, ban, mute, etc.)
        moderator (discord.Member): The moderator who performed the action
        target (discord.Member): The target of the action
        reason (str, optional): The reason for the action
        duration (str, optional): Duration for temporary actions
    """
    try:
        config = await get_config()
        log_channel_id = config.get('log_channel_id')
        
        if not log_channel_id:
            logger.warning("No log channel ID configured")
            return
        
        log_channel = guild.get_channel(log_channel_id)
        if not log_channel or not hasattr(log_channel, 'send'):
            logger.warning(f"Log channel {log_channel_id} not found or not a text channel")
            return
        
        # Import embeds here to avoid circular imports
        from utils.embeds import create_embed
        
        # Create action-specific embed
        action_colors = {
            'kick': 0xFF9500,  # Orange
            'ban': 0xFF0000,   # Red
            'mute': 0xFFFF00,  # Yellow
            'timeout': 0xFFFF00, # Yellow
            'unmute': 0x00FF00, # Green
            'untimeout': 0x00FF00 # Green
        }
        
        color = action_colors.get(action.lower(), 0x2ECC71)  # Default green
        
        title = f"🔨 {action.title()} Action"
        description = f"**Target:** {target.mention} ({target})\n**Moderator:** {moderator.mention} ({moderator})"
        
        if reason:
            description += f"\n**Reason:** {reason}"
        
        if duration:
            description += f"\n**Duration:** {duration}"
        
        description += f"\n**Time:** <t:{int(discord.utils.utcnow().timestamp())}:F>"
        
        embed = create_embed(
            title=title,
            description=description,
            color=color
        )
        
        embed.set_thumbnail(url=target.display_avatar.url)
        embed.set_footer(text=f"User ID: {target.id}")
        
        await log_channel.send(embed=embed)
        logger.info(f"Logged {action} action for {target} by {moderator}")
        
    except Exception as e:
        logger.error(f"Failed to log moderation action: {e}")

async def log_ticket_action(guild: discord.Guild, action: str, user: discord.Member, ticket_channel: discord.TextChannel, subject: str = None, moderator: discord.Member = None):
    """
    Log a ticket action to the configured log channel
    
    Args:
        guild (discord.Guild): The guild where the action occurred
        action (str): The action performed (create, close, claim)
        user (discord.Member): The user who performed the action (or ticket creator)
        ticket_channel (discord.TextChannel): The ticket channel
        subject (str, optional): The ticket subject for creation
        moderator (discord.Member, optional): The moderator for close/claim actions
    """
    try:
        config = await get_config()
        log_channel_id = config.get('log_channel_id')
        
        if not log_channel_id:
            logger.warning("No log channel ID configured")
            return
        
        log_channel = guild.get_channel(log_channel_id)
        if not log_channel or not hasattr(log_channel, 'send'):
            logger.warning(f"Log channel {log_channel_id} not found or not a text channel")
            return
        
        # Import embeds here to avoid circular imports
        from utils.embeds import create_embed
        
        # Create action-specific embed
        action_colors = {
            'create': 0x2ECC71,   # Green
            'close': 0xE74C3C,    # Red
            'claim': 0xF39C12,    # Orange
            'reopen': 0x3498DB    # Blue
        }
        
        color = action_colors.get(action.lower(), 0x2ECC71)
        
        if action.lower() == 'create':
            title = f"🎫 Ticket Created"
            description = f"**User:** {user.mention} ({user})\n**Channel:** {ticket_channel.mention}\n**Subject:** {subject}"
        elif action.lower() == 'close':
            title = f"🔒 Ticket Closed"
            description = f"**Channel:** {ticket_channel.mention}\n**Closed by:** {moderator.mention if moderator else user.mention}"
        elif action.lower() == 'claim':
            title = f"✋ Ticket Claimed"
            description = f"**Channel:** {ticket_channel.mention}\n**Claimed by:** {moderator.mention if moderator else user.mention}"
        else:
            title = f"🎫 Ticket {action.title()}"
            description = f"**Channel:** {ticket_channel.mention}\n**User:** {user.mention}"
        
        description += f"\n**Time:** <t:{int(discord.utils.utcnow().timestamp())}:F>"
        
        embed = create_embed(
            title=title,
            description=description,
            color=color
        )
        
        embed.set_thumbnail(url=user.display_avatar.url)
        embed.set_footer(text=f"Channel ID: {ticket_channel.id}")
        
        await log_channel.send(embed=embed)
        logger.info(f"Logged ticket {action} for {ticket_channel.name} by {user}")
        
    except Exception as e:
        logger.error(f"Failed to log ticket action: {e}")
