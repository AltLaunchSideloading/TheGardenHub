# Discord Moderation Bot

A comprehensive Discord moderation bot with advanced management capabilities, designed to enhance server administration through intelligent slash commands, ticket systems, and moderation tools.

## Features

- **Moderation Commands**: Kick, ban, timeout, warn, and purge messages
- **Ticket System**: User-friendly support ticket creation and management
- **Auto-Role Assignment**: Automatically assigns roles to new members
- **Comprehensive Logging**: Tracks all server activities and moderation actions
- **Utility Commands**: Server information, user lookup, and administrative tools
- **Slash Commands**: Modern Discord command interface

## Quick Setup

### 1. Prerequisites

- Python 3.11 or higher
- A Discord bot application (created at https://discord.com/developers/applications)

### 2. Installation

1. **Download/Clone** this project to your platform
2. **Install dependencies**:
   ```bash
   pip install discord.py python-dotenv aiosqlite
   ```

### 3. Bot Setup

1. **Create a Discord Application**:
   - Go to https://discord.com/developers/applications
   - Click "New Application" and give it a name
   - Go to the "Bot" section
   - Click "Reset Token" and copy the token (keep it secret!)

2. **Invite Bot to Server**:
   - Go to "OAuth2" → "URL Generator"
   - Select "bot" and "applications.commands" scopes
   - Select required permissions (Administrator recommended)
   - Use the generated URL to invite the bot

### 4. Running the Bot

**Option 1: Put token directly in code (Easiest)**
1. Open `main.py`
2. Find line 99: `BOT_TOKEN = "YOUR_BOT_TOKEN"`
3. Replace `YOUR_BOT_TOKEN` with your actual Discord bot token
4. Save and run: `python main.py`

**Option 2: Enter token when prompted**
1. Run: `python main.py`
2. Enter your Discord bot token when prompted
3. Token will be saved to `config.json` for future runs

### 5. Configuration

After the first run, you can customize settings in `config.json`:

```json
{
    "bot_token": "your_bot_token_here",
    "guild_ids": [],
    "mod_role_name": "Moderator",
    "admin_role_name": "Admin",
    "log_channel_name": "mod-logs",
    "ticket_category_name": "Support Tickets",
    "ticket_log_channel": "ticket-logs"
}
```

## Platform Compatibility

This bot is designed to work on any Python-supporting platform:

- ✅ **Pella.app** - Free 24/7 hosting (see PELLA_DEPLOYMENT.md)
- ✅ **Replit** - Ready to run
- ✅ **Heroku** - Add `python main.py` to Procfile  
- ✅ **Railway** - Works out of the box
- ✅ **Local Machine** - Run with Python
- ✅ **VPS/Cloud Servers** - Compatible with Linux/Windows
- ✅ **PythonAnywhere** - Supports the required libraries
- ✅ **Google Cloud Run** - Container-ready

### Special Notes for Hosting Platforms:
- **No cache files needed** - bot has inline fallbacks for all imports
- **Self-contained** - database and web server built into main.py
- **Clean deployment** - run `python deploy.py` before uploading

## Required Permissions

Your Discord bot needs these permissions:
- Manage Channels
- Manage Messages
- Manage Roles
- Kick Members
- Ban Members
- Moderate Members (for timeouts)
- Read Message History
- Send Messages
- Use Slash Commands

## File Structure

```
├── main.py              # Main bot file
├── config.json          # Configuration file (auto-created)
├── database.py          # Database management
├── keep_alive.py        # Uptime server (optional)
├── cogs/               # Bot commands organized by category
│   ├── moderation.py   # Moderation commands
│   ├── tickets.py      # Ticket system
│   ├── utilities.py    # Utility commands
│   ├── giveaways.py    # Giveaway system
│   ├── autoroles.py    # Auto-role assignment
│   └── logging.py      # Activity logging
└── utils/              # Helper utilities
    ├── embeds.py       # Embed creation
    └── permissions.py  # Permission checking
```

## Troubleshooting

### Common Issues:

1. **"Invalid bot token"**
   - Verify your token is correct
   - Make sure you copied the entire token
   - Regenerate the token if needed

2. **"Missing permissions"**
   - Ensure the bot has Administrator permissions
   - Check that bot role is above other roles you want to manage

3. **Commands not appearing**
   - Wait a few minutes after inviting the bot
   - Try kicking and re-inviting the bot
   - Ensure bot has "applications.commands" scope

## Support

If you encounter any issues:
1. Check the console output for error messages
2. Verify your bot token and permissions
3. Ensure all required channels and roles exist in your server

---

**Note**: Keep your bot token secure and never share it publicly!